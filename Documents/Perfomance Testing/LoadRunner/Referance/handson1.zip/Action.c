Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("currency=USD; DOMAIN=www.opencart.com");

	web_add_cookie("__cfduid=d1d49ba9d4d1d68dd95c158d45912382f1615979396; DOMAIN=www.opencart.com");

	web_add_cookie("_ga=GA1.2.1593833090.1616061121; DOMAIN=www.opencart.com");

	web_add_cookie("_gid=GA1.2.1939381640.1616061121; DOMAIN=www.opencart.com");

	web_url("opencart.com", 
		"URL=https://opencart.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.opencart.com/application/view/javascript/fontawesome/fonts/fontawesome-webfont.eot?", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.opencart.com/application/view/stylesheet/fonts/opencart.eot?h4wsna", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.opencart.com/application/view/stylesheet/fonts/SourceSansPro-Regular.ttf", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.googletagmanager.com/gtag/js?id=UA-1988725-1&l=dataLayer&cx=c", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", "Referer=https://www.opencart.com/", ENDITEM, 
		LAST);

	web_add_cookie("_gat_gtag_UA_1988725_1=1; DOMAIN=www.opencart.com");

	web_custom_request("collect", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j88&a=181119715&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2F&ul=en-us&de=utf-8&dt=OpenCart%20-%20Open%20Source%20Shopping%20Cart%20Solution&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQAAAAAAC~&jid=39290057&gjid=723268331&cid=1593833090.1616061121&tid=UA-1988725-1&_gid=1939381640.1616061121&_r=1&gtm=2ou3a0&z=1711534361", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.opencart.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		EXTRARES, 
		"Url=https://www.opencart.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	/* open marketplace */

	lr_think_time(17);

	web_url("index.php", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j88&a=752578727&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension&ul=en-us&de=utf-8&dt=OpenCart%20-%20Marketplace&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQ~&jid=&gjid=&cid=1593833090.1616061121&tid=UA-1988725-1&_gid=1939381640.1616061121&gtm=2ou3a0&z=373497104", "Referer=https://www.opencart.com/index.php?route=marketplace/extension", ENDITEM, 
		"Url=/application/view/image/banner/extensions.jpg", "Referer=https://www.opencart.com/index.php?route=marketplace/extension", ENDITEM, 
		LAST);

	/* search for paypal */

	web_url("index.php_2", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension&filter_search=paypal", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("collect_2", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j88&a=570995969&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension%26filter_search%3Dpaypal&ul=en-us&de=utf-8&dt=OpenCart%20-%20Marketplace&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQAAAAAAC~&jid=858763200&gjid=446559391&cid=1593833090.1616061121&tid=UA-1988725-1&_gid=1939381640.1616061121&_r=1&gtm=2ou3a0&z=188721442", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search=paypal", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	/* search for facebook */

	web_url("index.php_3", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension&filter_search=facebook", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search=paypal", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j88&a=1813227994&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension%26filter_search%3Dfacebook&ul=en-us&de=utf-8&dt=OpenCart%20-%20Marketplace&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQ~&jid=&gjid=&cid=1593833090.1616061121&tid=UA-1988725-1&_gid=1939381640.1616061121&gtm=2ou3a0&z=569718450", "Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search="
		"facebook", ENDITEM, 
		LAST);

	/* close marketplace */

	web_url("Marketplace", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search=facebook", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	/* close */

	return 0;
}