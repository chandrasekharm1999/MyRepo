Action()
{

	char aSeparator[2];
	char aSeparator1[2];
	char pstr1[100];
	int a,b;
	char pstr2[100]={0};
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_max_html_param_len("9999999"); 
	
	web_cleanup_cookies();
	
	web_cache_cleanup();


	web_set_user("R1-CORE.R1.AIG.NET\\smr", 
		"Sathish@6608", 
		"uatiwaokta.aig.net:443");
	
	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	lr_start_transaction("SC020_Sailpoint_Access_Revoke_T01_Launch");
//					00PrXJp0HW5-IlOCJ5AzCqu1tC-dBBlW1KA4sbde5T
//	var stateToken = "00PrXJp0HW5\x2DIlOCJ5AzCqu1tC\x2DdBBlW1KA4sbde5T";
	web_reg_save_param_ex(
		"ParamName=C_StateToken1",
		"LB=var stateToken = \"",
		"RB=\";",
		SEARCH_FILTERS,
		LAST);

	web_url("home.jsf", 
		"URL=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	strcpy(pstr1,lr_eval_string("{C_StateToken1}"));
	strcpy(aSeparator,"\\");
	strcpy(aSeparator1,"-");
	
	lr_output_message("%s",pstr1);
//	lr_log_message("%s",lr_save_string("pstr2","App");
	pstr2[0]='\0';

	for(a=0,b=0;pstr1[a]!=NULL;a++,b++)
	{
    if(pstr1[a]==aSeparator[0])
    {
    	pstr2[b]=aSeparator1[0];
        pstr2[b+1]=pstr1[a+4];
        a=a+5;
        b=b+2;
        
      //  lr_log_message("%s",pstr2);
    }
    pstr2[b]=pstr1[a];
    
    lr_log_message("%s",pstr2);
    
	}

	lr_save_string(lr_eval_string(pstr2), "StateToken");
	
	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"102\", \"Google Chrome\";v=\"102\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_reg_find("Search=Body",
	             "SaveCount=textcheck01",
				"Text=uataigtech - Sign In",
		LAST);

	web_url("{StateToken}", 
		"URL=https://uataigtech.oktapreview.com/login/interact/{StateToken}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/login/login.htm?fromURI="
		"%2Fapp%2Fsailpointiiq%2Fexknwm9rmiVHZYHEo0h7%2Fsso%2Fsaml%3FSAMLRequest%3DnVNdb9pAEHzvr7Du3R8YaOCEHVFoBFLaInAiNS%252FVcV6Ha%252Bw753YN5N%252F3MCHhoUFVX%252Fd2Zmdn9kbX%252B6r0tmBRGZ2wThAxD7Q0udKPCbvLbvwBu04%252FjVBUZVzzcUMbvYTnBpC8MSJYcriJ0dhUYFdgt0rC3fI2YRuiGnkYqhw0KXpRz42gQKjHQAOdVcONqSD4jQXzpo5UaUGtkhPeoRyIQG4C80SitrBVsAukqUJR1yEKVdZGOTJHBfsnvauGtlL3s4efs68m2lyFiCY8qGfejbES2g0SVogSgXnzacJ%252BQSS7sehKX%252BTF0O9dxQN%252FOJC5D7IvIe%252Bve%252Buo41pxIRDVFt7BiA3MNZLQlLA4imM%252F%252BuzHgyzq826P9zpB"
		"L%252B48MG9hDRlpyi9KH21trOZGoEKuRQXISfLV%252BNstj4OIr49NyGdZtvAXP1YZ8%252B5P8cSHeFxgGvkxkMtc9etglh7z461ie85wmUCcEmbpP%252Bc5Cs9npafL%252Be7I59OFKZV88cZlaXYTC4Kcm2QbaMOpBH0spxN02orK%252FaJt5Y3GGqQqFOQsfJvzepyQt0G7yyTYkzcxVS2swoOJsBeS3iw5b5uUbuElFP9l0MU2yeWB25UPR7QzNj8cBUinM7PCLWIsnYz7m6L09fGD%252Fd6fzz9o%252Bgc%253D%26RelayState%3Dhttps%253A%252F%252Fidentityiquat.aig.net%252Fidentityiq%252Fhome.jsf", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://op1static.oktacdn.com/assets/js/mvc/loginpage/initLoginPage.pack.47db94d2da847bad7e35886ca1ebf00e.js", "Referer=https://uataigtech.oktapreview.com/", ENDITEM, 
		LAST);

	web_add_auto_header("Accept", 
		"application/json");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Accept-Language", 
		"en");

	web_add_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_add_header("X-Okta-User-Agent-Extended", 
		"okta-auth-js/6.4.5 okta-signin-widget-6.3.2");

	web_custom_request("introspect", 
		"URL=https://uataigtech.oktapreview.com/api/v1/authn/introspect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/signin/refresh-auth-state/{StateToken}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"stateToken\":\"{StateToken}\"}", 
		LAST);

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("iframe.html", 
		"URL=https://login.okta.com/discovery/iframe.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);
		
	if(atoi(lr_eval_string("{textcheck01}"))==0)
	{
		lr_end_transaction("SC020_Sailpoint_Access_Revoke_T01_Launch", LR_FAIL);
		
		lr_error_message("SC020_Sailpoint_Access_Revoke_T01_Launch failed for  Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	else{
		
	lr_end_transaction("SC020_Sailpoint_Access_Revoke_T01_Launch", LR_AUTO);
	}

	lr_think_time(10);
	
	/* enter user name and password */

	/* click login */

	web_add_cookie("oktaStateToken={StateToken}; DOMAIN=uataigtech.oktapreview.com");
	
	lr_start_transaction("SC020_Sailpoint_Access_Revoke_T02_Login");
	
	web_add_header("Accept", 
		"application/json, text/javascript, */*; q=0.01");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Okta-XsrfToken", 
		"");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"102\", \"Google Chrome\";v=\"102\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("getimage", 
		"URL=https://uataigtech.oktapreview.com/login/getimage?username=Sathishkumar.Mr%40aig.com", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("devicefingerprint", 
		"URL=https://uataigtech.oktapreview.com/auth/services/devicefingerprint", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Accept", 
		"*/*");

	web_add_auto_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("nonce", 
		"URL=https://uataigtech.oktapreview.com/api/v1/internal/device/nonce", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/auth/services/devicefingerprint", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_auto_header("Accept", 
		"application/json");

	web_add_auto_header("Accept-Language", 
		"en");

	web_add_header("X-Device-Fingerprint", 
		"DggM43WJz9haJJbsLgTkPiruv2rB8K37|9070c8832a73068957ece0d779eef3a74c05246ae3f426c9083df2795406b130|fbda330b6f01b9f5203adb2bcb7cf752");

	web_add_header("X-Okta-User-Agent-Extended", 
		"okta-auth-js/6.4.5 okta-signin-widget-6.3.2");

	web_custom_request("authn", 
		"URL=https://uataigtech.oktapreview.com/api/v1/authn", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"password\":\"Sathish@6608\",\"username\":\"Sathishkumar.Mr@aig.com\",\"options\":{\"warnBeforePasswordExpired\":true,\"multiOptionalFactorEnroll\":true},\"stateToken\":\"{StateToken}\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("redirect", 
		"URL=https://uataigtech.oktapreview.com/login/token/redirect?stateToken={StateToken}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_revert_auto_header("Upgrade-Insecure-Requests");

//	<input type="hidden" name="javax.faces.ViewState" id="j_id1:javax.faces.ViewState:0" value="6940650839169208304:-6738613936178161636" autocomplete="off" />
	web_reg_save_param("C_javaxViewState1","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete",LAST);
	
	web_add_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_submit_form("home.jsf_2", 
		"Snapshot=t16.inf", 
		ITEMDATA, 
		LAST);

//	web_add_cookie("CSRF-TOKEN=0VoChsvWajCBRClWz7Hk6WJDojarKm26vswBvzoJ/p8%3D; DOMAIN=identityiquat.aig.net");

	web_add_header("Origin", 
		"https://identityiquat.aig.net");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

//	 Ext.util.Cookies.set('CSRF-TOKEN', '0VoChsvWajCBRClWz7Hk6WJDojarKm26vswBvzoJ/p8=');
	web_reg_save_param("C_XSRFTOKEN","LB=Ext.util.Cookies.set('CSRF-TOKEN', '","RB=');",LAST);
	
//	<input type="hidden" name="javax.faces.ViewState" id="j_id1:javax.faces.ViewState:0" value="-1041727560578942332:6910489216110884748" autocomplete="off" />
	web_reg_save_param("C_javaxViewState2","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete",LAST);
	
//	SailPoint.CURR_USER_ID = '0aa2c5617db81bf8817dbe25ee506417';
	web_reg_save_param("C_CurUserID","LB=SailPoint.CURR_USER_ID = '","RB=';",LAST);
	
	web_submit_data("setTimeZone.jsf", 
		"Action=https://identityiquat.aig.net/identityiq/ui/setTimeZone.jsf", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/ui/setTimeZone.jsf", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=timeZoneForm", "Value=timeZoneForm", ENDITEM, 
		"Name=timeZoneForm:initializeTimeZoneButton", "Value=", ENDITEM, 
		"Name=timeZoneForm:initialTimeZoneId", "Value=Asia/Calcutta", ENDITEM, 
		"Name=timeZoneForm:redirectHash", "Value=", ENDITEM, 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState1}", ENDITEM, 
		LAST);
	
	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("X-XSRF-TOKEN", 
		"{C_XSRFTOKEN}");

	web_url("count", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1618568198287", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	//web_add_cookie("XSRF-TOKEN={C_XSRFTOKEN}; DOMAIN=identityiquat.aig.net");

	web_url("messageCatalog", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/messageCatalog?ad1fcefc336-20200715-171039&lang=en-us", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/me/home", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Search=Body",
		"SaveCount=textcheck02",
		"Text=\"success\"",
		LAST);

	web_url("myAccessReviews", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/certifications/widgets/myAccessReviews?limit=5&start=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);
	if(atoi(lr_eval_string("{textcheck02}"))==0)
	{
		lr_end_transaction("SC020_Sailpoint_Access_Revoke_T02_Login", LR_FAIL);
		
		lr_error_message("SC020_Sailpoint_Access_Revoke_T02_Login failed for  Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	else{
		
	lr_end_transaction("SC020_Sailpoint_Access_Revoke_T02_Login", LR_AUTO);
	}
	
	lr_think_time(10);

	/* Click Menu */

	/* Click manage Identity */

	/* Click Access Revoke */

	lr_start_transaction("SC020_Sailpoint_Access_Revoke_T03_Click_Manage_Identity&Access_Revoke");

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Origin", 
		"https://identityiquat.aig.net");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	web_reg_save_param("C_javaxViewState3","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete",LAST);

	web_submit_data("home.jsf_3", 
		"Action=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=quickLinksForm", "Value=quickLinksForm", ENDITEM, 
		"Name=quickLinksForm:quickLink", "Value=Access Revoke", ENDITEM, 
		"Name=quickLinksForm:identityId", "Value={C_CurUserID}", ENDITEM, 
		"Name=quickLinksForm:chooseQuickLinkBtn", "Value=", ENDITEM, 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState2}", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("X-XSRF-TOKEN", 
		"{C_XSRFTOKEN}");

	web_url("count_2", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1656683685368", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("common-work-item.jsf", 
		"URL=https://identityiquat.aig.net/identityiq/ui/js/workitem/template/common-work-item.jsf", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("session", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/workItems/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Search=Body",
		"SaveCount=textcheck03",
		"Text=\"AIG-Identity-UpdateForm\"",
		LAST);

	web_url("session_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{textcheck03}"))==0)
	{
		lr_end_transaction("SC020_Sailpoint_Access_Revoke_T03_Click_Manage_Identity&Access_Revoke", LR_FAIL);
		
		lr_error_message("SC020_Sailpoint_Access_Revoke_T03_Click_Manage_Identity&Access_Revoke failed for  Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	else{
		
	lr_end_transaction("SC020_Sailpoint_Access_Revoke_T03_Click_Manage_Identity&Access_Revoke", LR_AUTO);
	}
	
	lr_think_time(10);

	//lr_end_transaction("SC020_Sailpoint_Access_Revoke_Click_Manage_Identity&Access_Revoke",LR_AUTO);

	/* Select Identity */

	lr_start_transaction("SC020_Sailpoint_Access_Revoke_T04_Select_Identity");

	web_add_auto_header("Origin", 
		"https://identityiquat.aig.net");

	

/*Correlation comment - Do not change!  Original value='8ada84fd23854d0c01238ddfd63408dc' Name ='CorrelationParameter' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=C_sourceIdentitySelected",
		"QueryString=$.objects[0].id",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_reg_find("Search=Body",
		"SaveCount=textcheck04",
		"Text=\"success\"",
		LAST);

	web_custom_request("sailpoint.object.Identity", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/suggest/object/sailpoint.object.Identity", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"sourceIdentitySelected\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"singleOrMultiple\":\"Single\",\"sourceIdentitySelected\":null},\"formId\":\"91bf90baf74e4c4aa6ea9915649b911e\",\"query\":\"{P_EID}\",\"limit\":5,\"filterString\":\"(((inactive == false && inactive.notNull()) && workerType != \\\"Nonhuman\\\") && correlated == true)\",\"extraParams\":{\"context\":\"CustomAttribute\",\"suggestId\":\""
		"AIG-Identity-UpdateForm-form-sourceIdentitySelected-field\"}}", 
		LAST);

	

	web_custom_request("postback",
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf",
		"Snapshot=t17.inf",
		"Mode=HTML",
		"EncType=application/json;charset=UTF-8",
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"singleOrMultiple\":\"Single\",\"sourceIdentitySelected\":\"{C_sourceIdentitySelected}\"}}",
		LAST);
	
	if(atoi(lr_eval_string("{textcheck04}"))==0)
	{
		lr_end_transaction("SC020_Sailpoint_Access_Revoke_T04_Select_Identity", LR_FAIL);
		
		lr_error_message("SC020_Sailpoint_Access_Revoke_T04_Select_Identity failed for  Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	else{
		
	lr_end_transaction("SC020_Sailpoint_Access_Revoke_T04_Select_Identity", LR_AUTO);
	}
	
	lr_think_time(10);
	

	//lr_end_transaction("SC020_Sailpoint_Access_Revoke_Select_Identity",LR_AUTO);

	/* Click Revoke */


	lr_start_transaction("SC020_Sailpoint_Access_Revoke_T05_Click_Revoke");
	
	web_custom_request("submit",
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/submit",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf",
		"Snapshot=t22.inf",
		"Mode=HTML",
		"EncType=application/json;charset=UTF-8",
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"singleOrMultiple\":\"Single\",\"sourceIdentitySelected\":\"{C_sourceIdentitySelected}\",\"ticketNumber\":null,\"requesterComments\":null},\"formId\":\"91bf90baf74e4c4aa6ea9915649b911e\",\"button\":{\"disabled\":false,\"loading\":true,\"action\":\"next\",\"actionParameter\":null,\"actionParameterValue\":null,\"label\":\"Revoke\",\"skipValidation\":false}}",
		LAST);

	web_revert_auto_header("X-XSRF-TOKEN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_revert_auto_header("Origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	web_reg_save_param("C_javaxViewState4","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete",LAST);
	

	web_submit_data("commonWorkItem.jsf", 
		"Action=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=transitionForm", "Value=transitionForm", ENDITEM, 
		"Name=transitionForm:transBtn", "Value=", ENDITEM, 
		"Name=transitionForm:messages", "Value=", ENDITEM, 
		"Name=transitionForm:outcome", "Value=viewHome", ENDITEM, 
		"Name=transitionForm:fallback", "Value=viewHome", ENDITEM, 
		"Name=transitionForm:back", "Value=false", ENDITEM, 
		"Name=transitionForm:navigationHistory", "Value=", ENDITEM, 
		"Name=transitionForm:noFlow", "Value=undefined", ENDITEM, 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState3}", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("X-XSRF-TOKEN", 
		"{C_XSRFTOKEN}");

	web_url("count_3", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1656683950484", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Search=Body",
		"SaveCount=textcheck05",
		"Text=\"MyAccessReviews\"",
		LAST);

	web_url("home_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/me/home", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("myAccessReviews_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/certifications/widgets/myAccessReviews?limit=5&start=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{textcheck05}"))==0)
	{
		lr_end_transaction("SC020_Sailpoint_Access_Revoke_T05_Click_Revoke", LR_FAIL);
		
		lr_error_message("SC020_Sailpoint_Access_Revoke_T05_Click_Revoke failed for  Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	else{
		
	lr_end_transaction("SC020_Sailpoint_Access_Revoke_T05_Click_Revoke", LR_AUTO);
	}
	
	lr_think_time(10);

	//lr_end_transaction("SC020_Sailpoint_Access_Revoke_Click_Revoke",LR_AUTO);
	
	lr_start_transaction("SC020_Sailpoint_Access_Revoke_T06_click_logout");

	web_submit_data("home.jsf_4", 
		"Action=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=headerForm", "Value=headerForm", ENDITEM, 
		"Name=headerForm:id", "Value=", ENDITEM, 
		"Name=headerForm:logoutButton", "Value=", ENDITEM, 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState4}", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_submit_data("home.jsf_5", 
		"Action=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/app/sailpointiiq/exknwm9rmiVHZYHEo0h7/sso/saml?SAMLRequest={C_Saml}&RelayState=%2Fidentityiq%2Fhome.jsf", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SAMLResponse", "Value={c_Saml2}", ENDITEM, 
		"Name=RelayState", "Value=/identityiq/home.jsf", ENDITEM, 
		LAST);	
	
	lr_end_transaction("SC020_Sailpoint_Access_Revoke_T06_click_logout",LR_AUTO);


	return 0;
}