Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");
	web_set_max_html_param_len("9999"); 
	web_cleanup_cookies();
	web_cache_cleanup();
 	
	web_reg_find("Search=Body",
		"SaveCount=T_Launch",
		"Text=ALIR",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_01_Launch");
	web_url("{P_url}",
		"URL=https://{P_url}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/_Incapsula_Resource?SSATYUBA=jse:T2JqZWN0IGRvZXNuJ3Qgc3VwcG9ydCBwcm9wZXJ0eSBvciBtZXRob2QgJ21hcCc=", ENDITEM, 
		LAST);

	web_url("index.jsp", 
		"URL=https://{P_url}/RRDWeb/web/index.jsp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/_Incapsula_Resource?SSATYUBA=jse:T2JqZWN0IGRvZXNuJ3Qgc3VwcG9ydCBwcm9wZXJ0eSBvciBtZXRob2QgJ21hcCc=", ENDITEM, 
		LAST);

	web_reg_save_param_ex(
		"ParamName=C_Statetoken1",
		"LB=x2Fredirect\\x3FstateToken\\x3D",
		"RB=';}}",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);
	web_reg_save_param("C_issuerID","LB=\"id\":\"","RB=\",\"uri\"",LAST);
	
	web_url("loginokta", 
		"URL=https://{P_url}/RRDWeb/loginokta", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/web/index.jsp", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://op3static.oktacdn.com/assets/js/mvc/loginpage/initLoginPage.pack.47db94d2da847bad7e35886ca1ebf00e.js", "Referer=https://uatauth1.customerpltfm.aig.com/login/login.htm?fromURI="
		"%2Fapp%2Faig-na-ciamuat1_uwalir_1%2Fexk2n909y4So7mmIQ1d7%2Fsso%2Fsaml%3FSAMLRequest%3DPD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c2FtbDJwOkF1dGhuUmVxdWVzdCB4bWxuczpzYW1sMnA9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpwcm90b2NvbCIgQXNzZXJ0aW9uQ29uc3VtZXJTZXJ2aWNlVVJMPSJodHRwczovL3VhdGF1dGgxLmN1c3RvbWVycGx0Zm0uYWlnLmNvbS9hcHAvYWlnLW5hLWNpYW11YXQxX3V3YWxpcl8xL2V4azJuOTA5eTRTbzdtbUlRMWQ3L3Nzby9zYW1sIiBJRD0iNzQ5YmFlNmEtZWY1Yi00NzMxLTkwOWItYjRiOWUyZDEyM2I5IiBJc3N1ZUluc3RhbnQ9IjIwMjItMDctMjJUMTA6MTI6"
		"MDkuNTI5WiIgUHJvdG9jb2xCaW5kaW5nPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YmluZGluZ3M6SFRUUC1QT1NUIiBWZXJzaW9uPSIyLjAiPjxzYW1sMjpJc3N1ZXIgeG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iPmh0dHA6Ly93d3cub2t0YS5jb20vZXhrMm45MDl5NFNvN21tSVExZDc8L3NhbWwyOklzc3Vlcj48c2FtbDJwOk5hbWVJRFBvbGljeSBGb3JtYXQ9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjEuMTpuYW1laWQtZm9ybWF0OnVuc3BlY2lmaWVkIi8%252BPHNhbWwycDpSZXF1ZXN0ZWRBdXRobkNvbnRleHQgQ29tcGFyaXNvbj0iZXhhY3QiPjxzYW1sMjpBdXRobkNvbnRleHRDbGFzc1JlZiB4bW"
		"xuczpzYW1sMj0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFzc2VydGlvbiI%252BdXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFjOmNsYXNzZXM6UGFzc3dvcmRQcm90ZWN0ZWRUcmFuc3BvcnQ8L3NhbWwyOkF1dGhuQ29udGV4dENsYXNzUmVmPjwvc2FtbDJwOlJlcXVlc3RlZEF1dGhuQ29udGV4dD48L3NhbWwycDpBdXRoblJlcXVlc3Q%252B", ENDITEM, 
//		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/font/montserrat-regular-webfont.eot?", "Referer=https://uatauth1.customerpltfm.aig.com/login/login.htm?fromURI="
//		"%2Fapp%2Faig-na-ciamuat1_uwalir_1%2Fexk2n909y4So7mmIQ1d7%2Fsso%2Fsaml%3FSAMLRequest%3DPD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c2FtbDJwOkF1dGhuUmVxdWVzdCB4bWxuczpzYW1sMnA9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpwcm90b2NvbCIgQXNzZXJ0aW9uQ29uc3VtZXJTZXJ2aWNlVVJMPSJodHRwczovL3VhdGF1dGgxLmN1c3RvbWVycGx0Zm0uYWlnLmNvbS9hcHAvYWlnLW5hLWNpYW11YXQxX3V3YWxpcl8xL2V4azJuOTA5eTRTbzdtbUlRMWQ3L3Nzby9zYW1sIiBJRD0iNzQ5YmFlNmEtZWY1Yi00NzMxLTkwOWItYjRiOWUyZDEyM2I5IiBJc3N1ZUluc3RhbnQ9IjIwMjItMDctMjJUMTA6MTI6"
//		"MDkuNTI5WiIgUHJvdG9jb2xCaW5kaW5nPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YmluZGluZ3M6SFRUUC1QT1NUIiBWZXJzaW9uPSIyLjAiPjxzYW1sMjpJc3N1ZXIgeG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iPmh0dHA6Ly93d3cub2t0YS5jb20vZXhrMm45MDl5NFNvN21tSVExZDc8L3NhbWwyOklzc3Vlcj48c2FtbDJwOk5hbWVJRFBvbGljeSBGb3JtYXQ9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjEuMTpuYW1laWQtZm9ybWF0OnVuc3BlY2lmaWVkIi8%252BPHNhbWwycDpSZXF1ZXN0ZWRBdXRobkNvbnRleHQgQ29tcGFyaXNvbj0iZXhhY3QiPjxzYW1sMjpBdXRobkNvbnRleHRDbGFzc1JlZiB4bW"
//		"xuczpzYW1sMj0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFzc2VydGlvbiI%252BdXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFjOmNsYXNzZXM6UGFzc3dvcmRQcm90ZWN0ZWRUcmFuc3BvcnQ8L3NhbWwyOkF1dGhuQ29udGV4dENsYXNzUmVmPjwvc2FtbDJwOlJlcXVlc3RlZEF1dGhuQ29udGV4dD48L3NhbWwycDpBdXRoblJlcXVlc3Q%252B", ENDITEM, 
//		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/font/montserrat-light-webfont.eot?", "Referer=https://uatauth1.customerpltfm.aig.com/login/login.htm?fromURI="
//		"%2Fapp%2Faig-na-ciamuat1_uwalir_1%2Fexk2n909y4So7mmIQ1d7%2Fsso%2Fsaml%3FSAMLRequest%3DPD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c2FtbDJwOkF1dGhuUmVxdWVzdCB4bWxuczpzYW1sMnA9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpwcm90b2NvbCIgQXNzZXJ0aW9uQ29uc3VtZXJTZXJ2aWNlVVJMPSJodHRwczovL3VhdGF1dGgxLmN1c3RvbWVycGx0Zm0uYWlnLmNvbS9hcHAvYWlnLW5hLWNpYW11YXQxX3V3YWxpcl8xL2V4azJuOTA5eTRTbzdtbUlRMWQ3L3Nzby9zYW1sIiBJRD0iNzQ5YmFlNmEtZWY1Yi00NzMxLTkwOWItYjRiOWUyZDEyM2I5IiBJc3N1ZUluc3RhbnQ9IjIwMjItMDctMjJUMTA6MTI6"
//		"MDkuNTI5WiIgUHJvdG9jb2xCaW5kaW5nPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YmluZGluZ3M6SFRUUC1QT1NUIiBWZXJzaW9uPSIyLjAiPjxzYW1sMjpJc3N1ZXIgeG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iPmh0dHA6Ly93d3cub2t0YS5jb20vZXhrMm45MDl5NFNvN21tSVExZDc8L3NhbWwyOklzc3Vlcj48c2FtbDJwOk5hbWVJRFBvbGljeSBGb3JtYXQ9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjEuMTpuYW1laWQtZm9ybWF0OnVuc3BlY2lmaWVkIi8%252BPHNhbWwycDpSZXF1ZXN0ZWRBdXRobkNvbnRleHQgQ29tcGFyaXNvbj0iZXhhY3QiPjxzYW1sMjpBdXRobkNvbnRleHRDbGFzc1JlZiB4bW"
//		"xuczpzYW1sMj0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFzc2VydGlvbiI%252BdXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFjOmNsYXNzZXM6UGFzc3dvcmRQcm90ZWN0ZWRUcmFuc3BvcnQ8L3NhbWwyOkF1dGhuQ29udGV4dENsYXNzUmVmPjwvc2FtbDJwOlJlcXVlc3RlZEF1dGhuQ29udGV4dD48L3NhbWwycDpBdXRoblJlcXVlc3Q%252B", ENDITEM, 
		"Url=https://op3static.oktacdn.com/fs/bco/1/fs0q5yyn3oUZi3Myh1d6", "Referer=https://uatauth1.customerpltfm.aig.com/signin/refresh-auth-state/00BUUJYa1kTIvtFOW8hmJP1NvA63gGo9LhU9m6-GQV", ENDITEM, 
//		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/img/security/default.png", "Referer=https://uatauth1.customerpltfm.aig.com/signin/refresh-auth-state/00BUUJYa1kTIvtFOW8hmJP1NvA63gGo9LhU9m6-GQV", ENDITEM, 
		LAST);

	lr_save_string(lr_eval_string("{C_Statetoken1}"),"hex_data1_copy");
			
	lr_save_string(lr_replace("hex_data1_copy","\\x2D","-"),"C_Statetoken");
	

	web_add_header("x-okta-user-agent-extended", 
		"okta-auth-js/5.8.0 okta-signin-widget-5.16.1");

	web_custom_request("introspect", 
		"URL=https://uatauth1.customerpltfm.aig.com/api/v1/authn/introspect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uatauth1.customerpltfm.aig.com/signin/refresh-auth-state/{C_Statetoken}", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"stateToken\":\"{C_Statetoken}\"}", 
		LAST);

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("sitelistv2.xml", 
		"URL=http://amproxy.aig.net/sitelistv2.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/img/ui/forms/checkbox-sign-in-widget.png", "Referer=https://uatauth1.customerpltfm.aig.com/", ENDITEM, 
		LAST);

	web_add_cookie("oktaStateToken={C_Statetoken}; DOMAIN=uatauth1.customerpltfm.aig.com");

	web_url("iframe.html", 
		"URL=https://login.okta.com/discovery/iframe.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uatauth1.customerpltfm.aig.com/signin/refresh-auth-state/{C_Statetoken}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=https://uatauth1.customerpltfm.aig.com/favicon.ico", "Referer=", ENDITEM, 
		"Url=https://uatauth1.customerpltfm.aig.com/.well-known/webfinger?resource=okta%3Aacct%3A{P_Username}%40perftest.com&requestContext="
		"%2Fapp%2Faig-na-ciamuat1_uwalir_1%2Fexk2n909y4So7mmIQ1d7%2Fsso%2Fsaml%3FSAMLRequest%3DPD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c2FtbDJwOkF1dGhuUmVxdWVzdCB4bWxuczpzYW1sMnA9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpwcm90b2NvbCIgQXNzZXJ0aW9uQ29uc3VtZXJTZXJ2aWNlVVJMPSJodHRwczovL3VhdGF1dGgxLmN1c3RvbWVycGx0Zm0uYWlnLmNvbS9hcHAvYWlnLW5hLWNpYW11YXQxX3V3YWxpcl8xL2V4azJuOTA5eTRTbzdtbUlRMWQ3L3Nzby9zYW1sIiBJRD0iNzQ5YmFlNmEtZWY1Yi00NzMxLTkwOWItYjRiOWUyZDEyM2I5IiBJc3N1ZUluc3RhbnQ9IjIwMjItMDctMjJUMTA6MTI6"
		"MDkuNTI5WiIgUHJvdG9jb2xCaW5kaW5nPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YmluZGluZ3M6SFRUUC1QT1NUIiBWZXJzaW9uPSIyLjAiPjxzYW1sMjpJc3N1ZXIgeG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iPmh0dHA6Ly93d3cub2t0YS5jb20vZXhrMm45MDl5NFNvN21tSVExZDc8L3NhbWwyOklzc3Vlcj48c2FtbDJwOk5hbWVJRFBvbGljeSBGb3JtYXQ9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjEuMTpuYW1laWQtZm9ybWF0OnVuc3BlY2lmaWVkIi8%252BPHNhbWwycDpSZXF1ZXN0ZWRBdXRobkNvbnRleHQgQ29tcGFyaXNvbj0iZXhhY3QiPjxzYW1sMjpBdXRobkNvbnRleHRDbGFzc1JlZiB4bW"
		"xuczpzYW1sMj0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFzc2VydGlvbiI%252BdXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFjOmNsYXNzZXM6UGFzc3dvcmRQcm90ZWN0ZWRUcmFuc3BvcnQ8L3NhbWwyOkF1dGhuQ29udGV4dENsYXNzUmVmPjwvc2FtbDJwOlJlcXVlc3RlZEF1dGhuQ29udGV4dD48L3NhbWwycDpBdXRoblJlcXVlc3Q%252B", "Referer=https://uatauth1.customerpltfm.aig.com/", ENDITEM, 
		LAST);
	
		if(atoi(lr_eval_string("{T_Launch}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_01_Launch", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_01_Launch : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_01_Launch", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);
	
		/* enter credentials and click login */
	
	web_reg_find("Search=Body",
		"SaveCount=T_Login",
		"Text=success",
		LAST);
	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_01b_EnterUsername");
	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("getimage", 
		"URL=https://uatauth1.customerpltfm.aig.com/login/getimage?username={P_Username}%40perftest.com", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uatauth1.customerpltfm.aig.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_url("devicefingerprint", 
		"URL=https://uatauth1.customerpltfm.aig.com/auth/services/devicefingerprint", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uatauth1.customerpltfm.aig.com/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/img/icons/login/tooltip_close.png", "Referer=https://uatauth1.customerpltfm.aig.com/", ENDITEM, 
//		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/img/security/unknown-device.png", "Referer=https://uatauth1.customerpltfm.aig.com/", ENDITEM, 
		LAST);

	web_add_auto_header("x-okta-user-agent-extended", 
		"okta-auth-js/5.8.0 okta-signin-widget-5.16.1");

	web_custom_request("authn", 
		"URL=https://uatauth1.customerpltfm.aig.com/api/v1/authn", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uatauth1.customerpltfm.aig.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"username\":\"{P_Username}@perftest.com\",\"options\":{\"warnBeforePasswordExpired\":true,\"multiOptionalFactorEnroll\":true},\"stateToken\":\"{C_Statetoken}\"}", 
		EXTRARES, 
//		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/font/okticon.eot?", "Referer=https://uatauth1.customerpltfm.aig.com/signin/verify/okta/password", ENDITEM, 
//		"Url=https://op3static.oktacdn.com/assets/js/sdk/okta-signin-widget/5.16.1/img/icons/mfa/password_70x70.png", "Referer=https://uatauth1.customerpltfm.aig.com/signin/verify/okta/password", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_Login}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_01b_EnterUsername", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_01b_EnterUsername : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_01b_EnterUsername", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}		
	
	lr_think_time(5);
	
	/* password */
	
	web_reg_find("Search=Body",
		"SaveCount=T_Login2",
		"Text=SUCCESS",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_01c_EnterPassword");

	web_custom_request("verify", 
		"URL=https://uatauth1.customerpltfm.aig.com/api/v1/authn/factors/password/verify?rememberDevice=false", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uatauth1.customerpltfm.aig.com/signin/verify/okta/password", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"password\":\"{P_Pwd}\",\"stateToken\":\"{C_Statetoken}\"}", 
		LAST);

	web_revert_auto_header("x-okta-user-agent-extended");

	web_url("redirect", 
		"URL=https://uatauth1.customerpltfm.aig.com/login/step-up/redirect?stateToken={C_Statetoken}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uatauth1.customerpltfm.aig.com/signin/verify/okta/password", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_form("loginokta_2", 
		"Snapshot=t12.inf", 
		ITEMDATA, 
		EXTRARES, 
//		"Url=images/aigfutura-bold-webfont.eot", ENDITEM, 
		"Url=../_Incapsula_Resource?SSATYUBA=jse:T2JqZWN0IGRvZXNuJ3Qgc3VwcG9ydCBwcm9wZXJ0eSBvciBtZXRob2QgJ21hcCc=", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_Login2}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_01c_EnterPassword", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_01c_EnterPassword : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_01c_EnterPassword", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}	
	
	lr_think_time(5);	
	
	web_reg_find("Search=Body",
		"SaveCount=T_SelectUser",
		"Text=TCS modifications for AIG rebranding ends",
		LAST);	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_02_Login");

	
	web_url("Controller", 
		"URL=https://{P_url}/RRDWeb/Controller?userIDTB=U1PVPCG&userRoleTB=PCG_USER&beanAlias=Login&loginBtn=Login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/loginokta", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=images/aigfutura-bold-webfont.eot", "Referer=https://{P_url}/RRDWeb/Controller?userIDTB=U1PVPCG&userRoleTB=PCG_USER&beanAlias=Login&loginBtn=Login", ENDITEM, 
		"Url=../_Incapsula_Resource?SSATYUBA=jse:T2JqZWN0IGRvZXNuJ3Qgc3VwcG9ydCBwcm9wZXJ0eSBvciBtZXRob2QgJ21hcCc=", "Referer=https://{P_url}/RRDWeb/Controller?userIDTB=U1PVPCG&userRoleTB=PCG_USER&beanAlias=Login&loginBtn=Login", ENDITEM, 
		LAST);
	
	
	if(atoi(lr_eval_string("{T_SelectUser}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_02_Login", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_02_Login : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_02_Login", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* report selection details */
	web_reg_find("Search=Body",
		"SaveCount=T_ReportSelect",
		"Text=Please Select Reporting state",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_03_EnterReportingSelectionDetails");

	web_submit_data("Controller_2", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=UserSelection&UserSelectionBtn=&functionName=startup", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=logUrl", "Value=Controller", ENDITEM, 
		"Name=stateCB", "Value=FL", ENDITEM, 
		"Name=companyCB", "Value=", ENDITEM, 
		"Name=SortOrderCB", "Value=Descending", ENDITEM, 
		"Name=beanAlias", "Value=UserSelection", ENDITEM, 
		"Name=UserSelectionBtn", "Value=stateCB", ENDITEM, 
		"Name=companyDesc", "Value=", ENDITEM, 
		"Name=stateDesc", "Value=", ENDITEM, 
		"Name=MandatoryFilters", "Value=", ENDITEM, 
		"Name=USER_ID", "Value=U1PVPCG", ENDITEM, 
		"Name=userAccess", "Value=", ENDITEM, 
		"Name=userType", "Value=PCG", ENDITEM, 
		"Name=stateMsgCB", "Value=", ENDITEM, 
		LAST);

	if(atoi(lr_eval_string("{T_ReportSelect}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_03_EnterReportingSelectionDetails", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_03_EnterReportingSelectionDetails : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_03_EnterReportingSelectionDetails", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* next */
	web_reg_find("Search=Body",
		"SaveCount=T_Next",
		"Text=ALIR Index",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_04_ClickNext");

	web_submit_data("Controller_3", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=logUrl", "Value=Controller", ENDITEM, 
		"Name=stateCB", "Value=FL", ENDITEM, 
		"Name=companyCB", "Value=19402", ENDITEM, 
		"Name=SortOrderCB", "Value=Descending", ENDITEM, 
		"Name=beanAlias", "Value=UserSelection", ENDITEM, 
		"Name=UserSelectionBtn", "Value=Next", ENDITEM, 
		"Name=companyDesc", "Value=19402 / AIG PROPERTY CASUALTY COMPANY", ENDITEM, 
		"Name=stateDesc", "Value= FLORIDA", ENDITEM, 
		"Name=MandatoryFilters", "Value=", ENDITEM, 
		"Name=USER_ID", "Value=U1PVPCG", ENDITEM, 
		"Name=userAccess", "Value=", ENDITEM, 
		"Name=userType", "Value=PCG", ENDITEM, 
		"Name=stateMsgCB", "Value=", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_Next}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_04_ClickNext", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_04_ClickNext : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_04_ClickNext", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* add */
	web_reg_find("Search=Body",
		"SaveCount=T_Add",
		"Text=Search Policy",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_05_ClickAdd");

	web_submit_data("Controller_4", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=Add", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-08-02.00.34.588209", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.887934", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.887934", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-08-02.00.34.588209", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_Add}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_05_ClickAdd", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_05_ClickAdd : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_05_ClickAdd", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* enter policy info */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_06_EnterPolicyDetails");

	web_submit_data("RemoteScripting", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623728270605147", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=PolicyTB", "Value={PolicyNumber}", ENDITEM, 
		"Name=ClientFieldString", "Value=", ENDITEM, 
		"Name=ClientMandFilterString", "Value=", ENDITEM, 
		"Name=ClientMandAddlFieldString", "Value=", ENDITEM, 
		"Name=USER_PRIVILAGE", "Value=ADMIN", ENDITEM, 
		"Name=beanAlias", "Value=PolicyDetail", ENDITEM, 
		"Name=PolicyDetailPgBtn", "Value=ChangePolicy", ENDITEM, 
		"Name=FROMPAGE", "Value=PolicyDetail", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=", ENDITEM, 
		"Name=TBKEYVALUE", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=EditValue", "Value=Add", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_06_EnterPolicyDetails", LR_AUTO);
	lr_think_time(5);

	/* add vehicle */
	web_reg_find("Search=Body",
		"SaveCount=T_AddVehicle",
		"Text=Vehicle Information Maintenance",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_07_ClickAddVehicle");
	web_submit_data("Controller_5", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ClientFieldString", "Value=", ENDITEM, 
		"Name=ClientMandFilterString", "Value=", ENDITEM, 
		"Name=ClientMandAddlFieldString", "Value=", ENDITEM, 
		"Name=USER_PRIVILAGE", "Value=ADMIN", ENDITEM, 
		"Name=PolicyTB", "Value={PolicyNumber}", ENDITEM, 
		"Name=PolicySearchCB", "Value=", ENDITEM, 
		"Name=EntitytypCB", "Value=1", ENDITEM, 
		"Name=IDCDTB", "Value=68885577", ENDITEM, 
		"Name=PolEffDtTB", "Value=20190101", ENDITEM, 
		"Name=PolExpDtTB", "Value=20200101", ENDITEM, 
		"Name=LNAMETB", "Value=LAST", ENDITEM, 
		"Name=FNAMETB", "Value=FIRST", ENDITEM, 
		"Name=MNAMETB", "Value=", ENDITEM, 
		"Name=DobTB", "Value=20180101", ENDITEM, 
		"Name=GenderCB", "Value=F", ENDITEM, 
		"Name=ADDRESSTB", "Value=ADD", ENDITEM, 
		"Name=CITYTB", "Value=CITY", ENDITEM, 
		"Name=STATECB", "Value=CA", ENDITEM, 
		"Name=ZIPTB", "Value=06041", ENDITEM, 
		"Name=postFlag", "Value=", ENDITEM, 
		"Name=ReportLevelCB", "Value=V", ENDITEM, 
		"Name=TranEffDtTB", "Value=", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=PolicyDetail", ENDITEM, 
		"Name=PolicyDetailPgBtn", "Value=AddVehicle", ENDITEM, 
		"Name=FROMPAGE", "Value=PolicyDetail", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=", ENDITEM, 
		"Name=TBKEYVALUE", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=EditValue", "Value=Add", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		LAST);
	if(atoi(lr_eval_string("{T_AddVehicle}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_07_ClickAddVehicle", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_07_ClickAddVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_07_ClickAddVehicle", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* vejicle information */

	/* click save vehicle */
	web_reg_find("Search=Body",
		"SaveCount=T_Save1",
		"Text=Transaction has been Added Successfully",
		LAST);
	
	
	web_reg_save_param("C_TRNO","LB=type=\"hidden\" name=\"TRNNO\" value=\"","RB=\">",LAST);
	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_08_SaveCurrentVehicle");

	web_submit_data("Controller_6", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=PolicyTB", "Value={PolicyNumber}", ENDITEM, 
		"Name=LNAMETB", "Value=LAST", ENDITEM, 
		"Name=PolEffDtTB", "Value=01/01/2019", ENDITEM, 
		"Name=PolExpDtTB", "Value=01/01/2020", ENDITEM, 
		"Name=TrantypCB", "Value=10", ENDITEM, 
		"Name=TranEffDtTB", "Value=20190101", ENDITEM, 
		"Name=VinTB", "Value={VehicleNumber}", ENDITEM, 
		"Name=yearTB", "Value=2019", ENDITEM, 
		"Name=makeTB", "Value=CHEV", ENDITEM, 
		"Name=CovglvlCB", "Value=02", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=postFlag", "Value=P", ENDITEM, 
		"Name=beanAlias", "Value=VehicleDetail", ENDITEM, 
		"Name=VehicleDetailPgBtn", "Value=SaveVehicleTransaction", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=20210614", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=POLICY", "Value={PolicyNumber}", ENDITEM, 
		"Name=ENTTYPQ", "Value=1", ENDITEM, 
		"Name=RPTLVL", "Value=V", ENDITEM, 
		"Name=STATE", "Value=CA", ENDITEM, 
		"Name=NONSTRNM", "Value=", ENDITEM, 
		"Name=NAMESFX", "Value=", ENDITEM, 
		"Name=LNAME", "Value=LAST", ENDITEM, 
		"Name=FNAME", "Value=FIRST", ENDITEM, 
		"Name=MNAME", "Value=", ENDITEM, 
		"Name=DOB", "Value=20180101", ENDITEM, 
		"Name=GENDER", "Value=F", ENDITEM, 
		"Name=IDCD", "Value=68885577", ENDITEM, 
		"Name=ADDRESS", "Value=ADD", ENDITEM, 
		"Name=CITY", "Value=CITY", ENDITEM, 
		"Name=ZIP", "Value=06041", ENDITEM, 
		"Name=NAIC", "Value=19402", ENDITEM, 
		"Name=RESRC", "Value=", ENDITEM, 
		"Name=POLEFFDT", "Value=20190101", ENDITEM, 
		"Name=POLEXPDT", "Value=20200101", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_Save1}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_08_SaveCurrentVehicle", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_08_SaveCurrentVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_08_SaveCurrentVehicle", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);
	
	/* back to manually entered */
	web_reg_find("Search=Body",
		"SaveCount=T_Back1",
		"Text=Policy Number",
		LAST);
//	web_reg_save_param("C_TBKeyVal","LB=type=\"hidden\" name=\"TBKEYVALUE\" value= \"","RB=\">",LAST);
	web_reg_save_param("C_TBKeyVal","LB=type=\"checkbox\" name=\"delCheck\" onclick=\'checkDel()\' value=\"","RB=\" ></TD>",LAST);
	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_09_BacktoManuallyEnteredPage");

	web_url("Controller_7", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	if(atoi(lr_eval_string("{T_Back1}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_09_BacktoManuallyEnteredPage", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_09_BacktoManuallyEnteredPage : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_09_BacktoManuallyEnteredPage", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* select any policy and click edit */
	web_reg_find("Search=Body",
		"SaveCount=T_PEdit1",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_10_SelectAnyPolicyAndClickEdit");

	web_submit_data("Controller_8", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, //2021-06-14-23.41.31.874472
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=Edit", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, //2021-06-08-02.00.34.589142
		"Name=browsestackvalue", "Value={C_TRNO}", ENDITEM, //2021-06-14-23.41.31.874472
		"Name=browsestackKEYvalue", "Value={C_TRNO}", ENDITEM, //2021-06-14-23.41.31.874472
		"Name=TBKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, //2021-06-08-02.00.34.589142
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	if(atoi(lr_eval_string("{T_PEdit1}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_10_SelectAnyPolicyAndClickEdit", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_10_SelectAnyPolicyAndClickEdit : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_10_SelectAnyPolicyAndClickEdit", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* change city and edkit vehicle */

//	web_reg_find("Search=Body",
//		"SaveCount=T_EditCity1",
//		"Text=Vehicle Information Maintenance",
//		LAST);
	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_11_ChangeCityAndClickEditVehicle");

	web_submit_data("Controller_9", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ClientFieldString", "Value=", ENDITEM, 
		"Name=ClientMandFilterString", "Value=", ENDITEM, 
		"Name=ClientMandAddlFieldString", "Value=", ENDITEM, 
		"Name=USER_PRIVILAGE", "Value=ADMIN", ENDITEM, 
		"Name=PolicyTB", "Value={PolicyNumber}", ENDITEM, 
		"Name=PolicySearchCB", "Value=", ENDITEM, 
		"Name=EntitytypCB", "Value=1", ENDITEM, 
		"Name=IDCDTB", "Value=68885577", ENDITEM, 
		"Name=PolEffDtTB", "Value=20190101", ENDITEM, 
		"Name=PolExpDtTB", "Value=20200101", ENDITEM, 
		"Name=LNAMETB", "Value=LAST", ENDITEM, 
		"Name=FNAMETB", "Value=FIRST", ENDITEM, 
		"Name=MNAMETB", "Value=", ENDITEM, 
		"Name=SuffixCB", "Value=", ENDITEM, 
		"Name=DobTB", "Value=20180101", ENDITEM, 
		"Name=GenderCB", "Value=F", ENDITEM, 
		"Name=ADDRESSTB", "Value=ADD", ENDITEM, 
		"Name=CITYTB", "Value={ChangeCity}", ENDITEM, 
		"Name=STATECB", "Value=CA", ENDITEM, 
		"Name=ZIPTB", "Value=06041", ENDITEM, 
		"Name=postFlag", "Value=P", ENDITEM, 
		"Name=ReportLevelCB", "Value=V", ENDITEM, 
		"Name=TrantypCB", "Value=10", ENDITEM, 
		"Name=TranEffDtTB", "Value=20190101", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=PolicyDetail", ENDITEM, 
		"Name=PolicyDetailPgBtn", "Value=ModifyVehicleAll", ENDITEM, 
		"Name=FROMPAGE", "Value=PolicyDetail", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value={C_TRNO}", ENDITEM, 
		"Name=TBKEYVALUE", "Value={C_TRNO}", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=EditValue", "Value=Modify", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		LAST);
	
//	if(atoi(lr_eval_string("{T_EditCity1}"))>0)
//	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_11_ChangeCityAndClickEditVehicle", LR_PASS);
//	}
//	else
//	{
//		lr_error_message("ALIR_PCG_ReportSelection_FL_11_ChangeCityAndClickEditVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
//		lr_end_transaction("ALIR_PCG_ReportSelection_FL_11_ChangeCityAndClickEditVehicle", LR_FAIL);
//		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
//	}
	lr_think_time(5);


	/* change vehicle make nad save vehicle */
	web_reg_find("Search=Body",
		"SaveCount=T_VEdit1",
		"Text=Transaction has been Updated Successfully",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_12_ChangeVehicleMakeAndClickSaveCurrentVehicle");

	web_submit_data("Controller_10", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=PolicyTB", "Value={PolicyNumber}", ENDITEM, 
		"Name=LNAMETB", "Value=LAST", ENDITEM, 
		"Name=PolEffDtTB", "Value=01/01/2019", ENDITEM, 
		"Name=PolExpDtTB", "Value=01/01/2020", ENDITEM, 
		"Name=TrantypCB", "Value=10", ENDITEM, 
		"Name=TranEffDtTB", "Value=20190101", ENDITEM, 
		"Name=VinTB", "Value={VehicleNumber}", ENDITEM, 
		"Name=yearTB", "Value=2019", ENDITEM, 
		"Name=makeTB", "Value={VehicleMake}", ENDITEM, 
		"Name=CovglvlCB", "Value=02", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=postFlag", "Value=P", ENDITEM, 
		"Name=beanAlias", "Value=VehicleDetail", ENDITEM, 
		"Name=VehicleDetailPgBtn", "Value=SaveVehicleTransaction", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=20210614", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=POLICY", "Value={PolicyNumber}", ENDITEM, 
		"Name=ENTTYPQ", "Value=1", ENDITEM, 
		"Name=RPTLVL", "Value=V", ENDITEM, 
		"Name=STATE", "Value=CA", ENDITEM, 
		"Name=NONSTRNM", "Value=", ENDITEM, 
		"Name=NAMESFX", "Value=", ENDITEM, 
		"Name=LNAME", "Value=LAST", ENDITEM, 
		"Name=FNAME", "Value=FIRST", ENDITEM, 
		"Name=MNAME", "Value=", ENDITEM, 
		"Name=DOB", "Value=20180101", ENDITEM, 
		"Name=GENDER", "Value=F", ENDITEM, 
		"Name=IDCD", "Value=68885577", ENDITEM, 
		"Name=ADDRESS", "Value=ADD", ENDITEM, 
		"Name=CITY", "Value={ChangeCity}", ENDITEM, 
		"Name=ZIP", "Value=06041", ENDITEM, 
		"Name=NAIC", "Value=19402", ENDITEM, 
		"Name=RESRC", "Value=", ENDITEM, 
		"Name=POLEFFDT", "Value=20190101", ENDITEM, 
		"Name=POLEXPDT", "Value=20200101", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_VEdit1}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_12_ChangeVehicleMakeAndClickSaveCurrentVehicle", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_12_ChangeVehicleMakeAndClickSaveCurrentVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_12_ChangeVehicleMakeAndClickSaveCurrentVehicle", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* back to maually entered */
	web_reg_find("Search=Body",
		"SaveCount=T_Back3",
		"Text=Policy Number",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_13_BackToManuallyEnteredPage");

	web_url("Controller_11", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	if(atoi(lr_eval_string("{T_Back3}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_13_BackToManuallyEnteredPage", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_13_BackToManuallyEnteredPage : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_13_BackToManuallyEnteredPage", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* select any policy click delete */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_14_SelectAnyPolicyAndClickDelete");

	web_submit_data("RemoteScripting_2", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=162372870149793", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=browsestackvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=browsestackKEYvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=TBKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_14_SelectAnyPolicyAndClickDelete", LR_AUTO);
	lr_think_time(5);

	/* undelete */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_15_ClickUnDelete");

	web_submit_data("RemoteScripting_3", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623728714528964", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=D", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=browsestackvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=browsestackKEYvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=TBKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_15_ClickUnDelete", LR_AUTO);
	lr_think_time(5);

	/* post */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_16_ClickPost");

	web_submit_data("RemoteScripting_4", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623728728270910", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value=P", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value=P", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=3", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=browsestackvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=browsestackKEYvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=TBKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_16_ClickPost", LR_AUTO);
	lr_think_time(5);

	/* unpost */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_17_ClickUnPost");
	web_submit_data("RemoteScripting_5", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623728741658535", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=browsestackvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=browsestackKEYvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=TBKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_17_ClickUnPost", LR_AUTO);
	lr_think_time(5);
/* clcik next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_18_ClickNext");
	
	web_submit_data("Controller_12", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=ECF&chkFlag=ECF", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value={C_TRNO}", ENDITEM, 
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=browsestackvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=browsestackKEYvalue", "Value={C_TRNO}", ENDITEM, 
		"Name=TBKEYVALUE", "Value={C_TBKeyVal}", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_18_ClickNext", LR_AUTO);
	lr_think_time(5);

	/* prev */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_19_ClickPrev");

	web_submit_data("Controller_13", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=PrevRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-07-02.00.33.889794", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-08-02.00.34.588209", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-08-02.00.34.588209", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-07-02.00.33.889794", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_19_ClickPrev", LR_AUTO);
	lr_think_time(5);

	/* next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_20_ClickNext");

	web_submit_data("Controller_14", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-08-02.00.34.589142", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-14-23.41.31.874472", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-14-23.41.31.874472", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-08-02.00.34.589142", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_20_ClickNext", LR_AUTO);
	lr_think_time(5);


	/* clcik first */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_21_ClickFirst");

	web_submit_data("Controller_15", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=FirstRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-07-02.00.33.889794", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-08-02.00.34.588209", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-08-02.00.34.588209", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-07-02.00.33.889794", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=Y", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_21_ClickFirst", LR_AUTO);
	lr_think_time(5);


	/* clcik state returned errors */
	web_reg_find("Search=Body",
		"SaveCount=T_SRError",
		"Text=Policy Number",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_21_ClickStateReturnedErrors");

	web_url("Controller_16", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{T_SRError}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_21_ClickStateReturnedErrors", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_21_ClickStateReturnedErrors : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_21_ClickStateReturnedErrors", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);


	/* select any policy click edit */
	web_reg_find("Search=Body",
		"SaveCount=T_PEdit2",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_22_SelectAnyPolicyAndClickEdit");

	web_submit_data("Controller_17", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=D", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=Edit", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_PEdit2}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_22_SelectAnyPolicyAndClickEdit", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_22_SelectAnyPolicyAndClickEdit : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_22_SelectAnyPolicyAndClickEdit", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}	
	lr_think_time(5);


	/* change city and click edit vehicle */
//	web_reg_find("Search=Body",
//		"SaveCount=T_EditCity2",
//		"Text=Vehicle Information Maintenance",
//		LAST);
	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_23_ChangeCityAndClickEditVehicle");
	
	web_submit_data("Controller_18",
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ClientFieldString", "Value=", ENDITEM, 
		"Name=ClientMandFilterString", "Value=", ENDITEM, 
		"Name=ClientMandAddlFieldString", "Value=", ENDITEM, 
		"Name=USER_PRIVILAGE", "Value=ADMIN", ENDITEM, 
		"Name=PolicyTB", "Value=0066821426", ENDITEM, 
		"Name=PolicySearchCB", "Value=", ENDITEM, 
		"Name=EntitytypCB", "Value=1", ENDITEM, 
		"Name=IDCDTB", "Value=", ENDITEM, 
		"Name=PolEffDtTB", "Value=20210518", ENDITEM, 
		"Name=PolExpDtTB", "Value=", ENDITEM, 
		"Name=LNAMETB", "Value=WINKLER", ENDITEM, 
		"Name=FNAMETB", "Value=KELLY", ENDITEM, 
		"Name=MNAMETB", "Value=", ENDITEM, 
		"Name=SuffixCB", "Value=", ENDITEM, 
		"Name=DobTB", "Value=19641213", ENDITEM, 
		"Name=GenderCB", "Value=F", ENDITEM, 
		"Name=ADDRESSTB", "Value=2375 ALEXANDER PALM DR", ENDITEM, 
		"Name=CITYTB", "Value={ChangeCity}", ENDITEM, 
		"Name=STATECB", "Value=FL", ENDITEM, 
		"Name=ZIPTB", "Value=34105", ENDITEM, 
		"Name=postFlag", "Value=D", ENDITEM, 
		"Name=ReportLevelCB", "Value=V", ENDITEM, 
		"Name=TrantypCB", "Value=11", ENDITEM, 
		"Name=TranEffDtTB", "Value=20210518", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=PolicyDetail", ENDITEM, 
		"Name=PolicyDetailPgBtn", "Value=ModifyVehicleAll", ENDITEM, 
		"Name=FROMPAGE", "Value=PolicyDetail", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=", ENDITEM, 
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM, 
		"Name=EditValue", "Value=Modify", ENDITEM, 
		"Name=SRCDT", "Value=20210607", ENDITEM, 
		LAST);
	
//	if(atoi(lr_eval_string("{T_EditCity2}"))>0)
//	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_23_ChangeCityAndClickEditVehicle", LR_PASS);
//	}
//	else
//	{
//		lr_error_message("ALIR_PCG_ReportSelection_FL_23_ChangeCityAndClickEditVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
//		lr_end_transaction("ALIR_PCG_ReportSelection_FL_23_ChangeCityAndClickEditVehicle", LR_FAIL);
//		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
//	}
	lr_think_time(5);


	/* change vehicle make */

	/* click save current vehicle */
	web_reg_find("Search=Body",
		"SaveCount=T_VEdit2",
		"Text=Transaction has been Updated Successfully",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_24_ChangeVehicleMakeAndClickSaveCurrentVehicle");

	web_submit_data("Controller_19", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=PolicyTB", "Value=0066821426", ENDITEM, 
		"Name=LNAMETB", "Value=WINKLER", ENDITEM, 
		"Name=PolEffDtTB", "Value=05/18/2021", ENDITEM, 
		"Name=PolExpDtTB", "Value=", ENDITEM, 
		"Name=TrantypCB", "Value=11", ENDITEM, 
		"Name=TranEffDtTB", "Value=20210518", ENDITEM, 
		"Name=VinTB", "Value=WDDEJ77X58A008976", ENDITEM, 
		"Name=yearTB", "Value=2008", ENDITEM, 
		"Name=makeTB", "Value={VehicleMake}", ENDITEM, 
		"Name=CovglvlCB", "Value=03", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=postFlag", "Value=D", ENDITEM, 
		"Name=beanAlias", "Value=VehicleDetail", ENDITEM, 
		"Name=VehicleDetailPgBtn", "Value=SaveVehicleTransaction", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=20210614", ENDITEM, 
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=POLICY", "Value=0066821426", ENDITEM, 
		"Name=ENTTYPQ", "Value=1", ENDITEM, 
		"Name=RPTLVL", "Value=V", ENDITEM, 
		"Name=STATE", "Value=FL", ENDITEM, 
		"Name=NONSTRNM", "Value=", ENDITEM, 
		"Name=NAMESFX", "Value=", ENDITEM, 
		"Name=LNAME", "Value=WINKLER", ENDITEM, 
		"Name=FNAME", "Value=KELLY", ENDITEM, 
		"Name=MNAME", "Value=", ENDITEM, 
		"Name=DOB", "Value=19641213", ENDITEM, 
		"Name=GENDER", "Value=F", ENDITEM, 
		"Name=IDCD", "Value=", ENDITEM, 
		"Name=ADDRESS", "Value=2375 ALEXANDER PALM DR", ENDITEM, 
		"Name=CITY", "Value={ChangeCity}", ENDITEM, 
		"Name=ZIP", "Value=34105", ENDITEM, 
		"Name=NAIC", "Value=19402", ENDITEM, 
		"Name=RESRC", "Value=", ENDITEM, 
		"Name=POLEFFDT", "Value=20210518", ENDITEM, 
		"Name=POLEXPDT", "Value=", ENDITEM, 
		LAST);

	if(atoi(lr_eval_string("{T_VEdit2}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_24_ChangeVehicleMakeAndClickSaveCurrentVehicle", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_24_ChangeVehicleMakeAndClickSaveCurrentVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_24_ChangeVehicleMakeAndClickSaveCurrentVehicle", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* back to state returned errors */
	web_reg_find("Search=Body",
		"SaveCount=T_SRError2",
		"Text=Policy Number",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_25_BackToStateReturnedErrors");

	web_url("Controller_20", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	if(atoi(lr_eval_string("{T_SRError2}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_25_BackToStateReturnedErrors", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_25_BackToStateReturnedErrors : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_25_BackToStateReturnedErrors", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* select any policy click delete */
	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_26_SelectAnyPolicyandClickDelete");


	web_submit_data("RemoteScripting_6", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729078877287", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.881381", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.883349", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM,
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_26_SelectAnyPolicyandClickDelete", LR_AUTO);
	lr_think_time(5);


	/* undelete */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_27_ClickUnDelete");


	web_submit_data("RemoteScripting_7", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729095866356", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.881381", ENDITEM,
		"Name=TRNNO", "Value=2021-06-09-02.00.32.883349", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=D", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM,
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_27_ClickUnDelete", LR_AUTO);
	lr_think_time(5);

	/* click post */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_28_ClickPost");

	web_submit_data("RemoteScripting_8", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729116485174", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value=P", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.881381", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.883349", ENDITEM, 
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value=P", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_28_ClickPost", LR_AUTO);
	lr_think_time(5);

	/* unpost */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_29_ClickUnPost");


	web_submit_data("RemoteScripting_9", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729138805134", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.881381", ENDITEM,
		"Name=TRNNO", "Value=2021-06-09-02.00.32.883349", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_29_ClickUnPost", LR_AUTO);
	lr_think_time(5);


	/* click next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_30_ClickNext");


	web_submit_data("Controller_21", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=DMV&chkFlag=DMVV", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.881381", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.883349", ENDITEM, 
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM,
		"Name=TRANSERRCODES", "Value=050,,,,,,,,,", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_30_ClickNext", LR_AUTO);
	lr_think_time(5);


	/* prev */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_31_ClickPrev");


	web_submit_data("Controller_22", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=PrevRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.855795", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.868679", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.868679", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.855795", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_31_ClickPrev", LR_AUTO);
	lr_think_time(5);


	/* next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_32_ClickNext");


	web_submit_data("Controller_23", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.884229", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.869563", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_32_ClickNext", LR_AUTO);
	lr_think_time(5);


	/* clcik first */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_33_ClicFirst");


	web_submit_data("Controller_24", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=FirstRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.855795", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.868679", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.868679", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.855795", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_33_ClicFirst", LR_AUTO);
	lr_think_time(5);


	/* click source error transactions */
	web_reg_find("Search=Body",
		"SaveCount=T_SError",
		"Text=Policy Number",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_34_ClickSourceErrorTransaction");

	web_url("Controller_25", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		LAST);
	if(atoi(lr_eval_string("{T_SError}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_34_ClickSourceErrorTransaction", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_34_ClickSourceErrorTransaction : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_34_ClickSourceErrorTransaction", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);


	/* select any polcy and click edit */
	web_reg_find("Search=Body",
		"SaveCount=T_PEdit2",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_35_SelectAnyPolicyandClickEdit");

	web_submit_data("Controller_26", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC1", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
//		"Name=TRNNO", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 		
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=Edit", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-04-15-09.52.35.618209", ENDITEM,
		"Name=TBSEARCHKEYVALUE", "Value=2013-03-07-01.41.17.240781", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2013-03-07-01.41.17.240781", ENDITEM,		
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_PEdit2}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_35_SelectAnyPolicyandClickEdit", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_35_SelectAnyPolicyandClickEdit : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_35_SelectAnyPolicyandClickEdit", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);


	/* change city and edit vehicle */

	/* edit vehicle */
//	web_reg_find("Search=Body",
//		"SaveCount=T_EditCity2",
//		"Text=Vehicle Information Maintenance",
//		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_36_ChangeCityAndEditVehicle");

	web_submit_data("Controller_27", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ClientFieldString", "Value=", ENDITEM, 
		"Name=ClientMandFilterString", "Value=", ENDITEM, 
		"Name=ClientMandAddlFieldString", "Value=", ENDITEM, 
		"Name=USER_PRIVILAGE", "Value=ADMIN", ENDITEM, 
//		"Name=PolicyTB", "Value=0093886388", ENDITEM, 
		"Name=PolicyTB", "Value=0066821793", ENDITEM, 
		"Name=PolicySearchCB", "Value=", ENDITEM, 
		"Name=EntitytypCB", "Value=1", ENDITEM, 
//		"Name=IDCDTB", "Value=P245620294198", ENDITEM, 
//		"Name=PolEffDtTB", "Value=20200606", ENDITEM, 
//		"Name=PolExpDtTB", "Value=20210606", ENDITEM, 
//		"Name=LNAMETB", "Value=PICKELNY", ENDITEM, 
//		"Name=FNAMETB", "Value=NORMAN", ENDITEM,
		"Name=IDCDTB", "Value=G435432589410", ENDITEM, 
		"Name=PolEffDtTB", "Value=20210602", ENDITEM, 
		"Name=PolExpDtTB", "Value=20220602", ENDITEM, 
		"Name=LNAMETB", "Value=GOLDENTESTCLIENT", ENDITEM, 
		"Name=FNAMETB", "Value=MARC", ENDITEM,		
		"Name=MNAMETB", "Value=", ENDITEM, 
		"Name=SuffixCB", "Value=", ENDITEM, 
//		"Name=DobTB", "Value=19291119", ENDITEM, 
//		"Name=GenderCB", "Value=M", ENDITEM, 
//		"Name=ADDRESSTB", "Value=C/O ANDREW ROD", ENDITEM,
		"Name=DobTB", "Value=19581201", ENDITEM, 
		"Name=GenderCB", "Value=F", ENDITEM, 
		"Name=ADDRESSTB", "Value=818 NE ORCHID BAY DR", ENDITEM,		
		"Name=CITYTB", "Value={ChangeCity}", ENDITEM, 
//		"Name=STATECB", "Value=VA", ENDITEM, 
//		"Name=ZIPTB", "Value=22903", ENDITEM,
		"Name=STATECB", "Value=FL", ENDITEM, 
		"Name=ZIPTB", "Value=33487", ENDITEM,		
		"Name=postFlag", "Value=", ENDITEM, 
		"Name=ReportLevelCB", "Value=V", ENDITEM, 
		"Name=TrantypCB", "Value=20", ENDITEM, 
//		"Name=TranEffDtTB", "Value=20200606", ENDITEM, 
		"Name=TranEffDtTB", "Value=20210602", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=PolicyDetail", ENDITEM, 
		"Name=PolicyDetailPgBtn", "Value=ModifyVehicle", ENDITEM, 
		"Name=FROMPAGE", "Value=PolicyDetail", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
//		"Name=TRNNO", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM,
		"Name=POSTUSRID", "Value=", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=", ENDITEM, 
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM, 
		"Name=EditValue", "Value=Modify", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		LAST);
	
//	if(atoi(lr_eval_string("{T_EditCity2}"))>0)
//	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_36_ChangeCityAndEditVehicle", LR_PASS);
//	}
//	else
//	{
//		lr_error_message("ALIR_PCG_ReportSelection_FL_36_ChangeCityAndEditVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
//		lr_end_transaction("ALIR_PCG_ReportSelection_FL_36_ChangeCityAndEditVehicle", LR_FAIL);
//		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
//	}
	lr_think_time(5);

	/* change vehicle make and save vehicle */
	web_reg_find("Search=Body",
		"SaveCount=T_VEdit2",
		"Text=Transaction has been Updated Successfully",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_37_ChangeVehicleMakendsaveVehicle");

	web_submit_data("Controller_28", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		ITEMDATA, 
//		"Name=PolicyTB", "Value=0093886388", ENDITEM, 
//		"Name=LNAMETB", "Value=PICKELNY", ENDITEM, 
//		"Name=PolEffDtTB", "Value=06/06/2020", ENDITEM, 
//		"Name=PolExpDtTB", "Value=06/06/2021", ENDITEM, 
//		"Name=TrantypCB", "Value=20", ENDITEM, 
//		"Name=TranEffDtTB", "Value=20200606", ENDITEM, 
//		"Name=VinTB", "Value=5GAKVBKD9FJ303420", ENDITEM, 
//		"Name=yearTB", "Value=2015", ENDITEM, 
		"Name=PolicyTB", "Value=0066821793", ENDITEM, 
		"Name=LNAMETB", "Value=GOLDENTESTCLIENT", ENDITEM, 
		"Name=PolEffDtTB", "Value=06/02/2021", ENDITEM, 
		"Name=PolExpDtTB", "Value=06/02/2022", ENDITEM, 
		"Name=TrantypCB", "Value=20", ENDITEM, 
		"Name=TranEffDtTB", "Value=20210602", ENDITEM, 
		"Name=VinTB", "Value=W1N0G8DB6LV262739", ENDITEM, 
		"Name=yearTB", "Value=2020", ENDITEM,
		"Name=makeTB", "Value={VehicleMake}", ENDITEM, 
		"Name=CovglvlCB", "Value=03", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=postFlag", "Value=P", ENDITEM, 
		"Name=beanAlias", "Value=VehicleDetail", ENDITEM, 
		"Name=VehicleDetailPgBtn", "Value=SaveVehicleTransaction", ENDITEM, 
//		"Name=TRNNO", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=20210614", ENDITEM, 
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
//		"Name=TRNNO", "Value=2021-04-15-09.52.35.618209", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
//		"Name=POLICY", "Value=0093886388", ENDITEM, 
		"Name=POLICY", "Value=0066821793", ENDITEM, 
		"Name=ENTTYPQ", "Value=1", ENDITEM, 
		"Name=RPTLVL", "Value=V", ENDITEM, 
//		"Name=STATE", "Value=VA", ENDITEM, 
		"Name=STATE", "Value=FL", ENDITEM, 
		"Name=NONSTRNM", "Value=", ENDITEM, 
		"Name=NAMESFX", "Value=", ENDITEM, 
//		"Name=LNAME", "Value=PICKELNY", ENDITEM, 
//		"Name=FNAME", "Value=NORMAN", ENDITEM, 
		"Name=LNAME", "Value=GOLDENTESTCLIENT", ENDITEM, 
		"Name=FNAME", "Value=MARC", ENDITEM,
		"Name=MNAME", "Value=", ENDITEM,
//		"Name=DOB", "Value=19291119", ENDITEM, 
//		"Name=GENDER", "Value=M", ENDITEM, 
//		"Name=IDCD", "Value=P245620294198", ENDITEM, 
//		"Name=ADDRESS", "Value=C/O ANDREW ROD", ENDITEM, 
		"Name=DOB", "Value=19581201", ENDITEM, 
		"Name=GENDER", "Value=F", ENDITEM, 
		"Name=IDCD", "Value=G435432589410", ENDITEM, 
		"Name=ADDRESS", "Value=818 NE ORCHID BAY DR", ENDITEM,
		"Name=CITY", "Value={ChangeCity}", ENDITEM,
//		"Name=ZIP", "Value=22903", ENDITEM, 
//		"Name=NAIC", "Value=19402", ENDITEM, 
//		"Name=RESRC", "Value=", ENDITEM, 
//		"Name=POLEFFDT", "Value=20200606", ENDITEM, 
//		"Name=POLEXPDT", "Value=20210606", ENDITEM, 
		"Name=ZIP", "Value=33487", ENDITEM, 
		"Name=NAIC", "Value=19402", ENDITEM, 
		"Name=RESRC", "Value=", ENDITEM, 
		"Name=POLEFFDT", "Value=20210602", ENDITEM, 
		"Name=POLEXPDT", "Value=20220602", ENDITEM,
		LAST);
	
	if(atoi(lr_eval_string("{T_VEdit2}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_37_ChangeVehicleMakendsaveVehicle", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_37_ChangeVehicleMakendsaveVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_37_ChangeVehicleMakendsaveVehicle", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);


	/* back to source error transactions */
	web_reg_find("Search=Body",
		"SaveCount=T_SError2",
		"Text=Policy Number",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_38_BacktoSourceErrorpage");

	web_url("Controller_29", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{T_SError2}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_38_BacktoSourceErrorpage", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_38_BacktoSourceErrorpage : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_38_BacktoSourceErrorpage", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);


	/* clcik souce posted transactions */
	web_reg_find("Search=Body",
		"SaveCount=T_SPTrans",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_39_ClickSourcePosted");

	web_url("Controller_30", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);
	if(atoi(lr_eval_string("{T_SPTrans}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_39_ClickSourcePosted", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_39_ClickSourcePosted : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_39_ClickSourcePosted", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* select any policy and click edit */
	web_reg_find("Search=Body",
		"SaveCount=T_PEdit4",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_40_SelectAnyPolicyAndClickEdit");

	web_submit_data("Controller_31", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=Edit", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_40_SelectAnyPolicyAndClickEdit", LR_AUTO);
	lr_think_time(5);


	/* change city and edit vehicle */
//	web_reg_find("Search=Body",
//		"SaveCount=T_EditCity4",
//		"Text=Vehicle Information Maintenance",
//		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_41_ChangecityAndEditVehicle");

	web_submit_data("Controller_32", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ClientFieldString", "Value=", ENDITEM, 
		"Name=ClientMandFilterString", "Value=", ENDITEM, 
		"Name=ClientMandAddlFieldString", "Value=", ENDITEM, 
		"Name=USER_PRIVILAGE", "Value=ADMIN", ENDITEM, 
		"Name=PolicyTB", "Value=0080865720", ENDITEM, 
		"Name=PolicySearchCB", "Value=", ENDITEM, 
		"Name=EntitytypCB", "Value=1", ENDITEM, 
		"Name=IDCDTB", "Value=", ENDITEM, 
		"Name=PolEffDtTB", "Value=20201112", ENDITEM, 
		"Name=PolExpDtTB", "Value=20211112", ENDITEM, 
		"Name=LNAMETB", "Value=VOIGT", ENDITEM, 
		"Name=FNAMETB", "Value=HANS-JOACH", ENDITEM, 
		"Name=MNAMETB", "Value=", ENDITEM, 
		"Name=SuffixCB", "Value=", ENDITEM, 
		"Name=DobTB", "Value=19530528", ENDITEM, 
		"Name=GenderCB", "Value=M", ENDITEM, 
		"Name=ADDRESSTB", "Value=560 EAGLE CREEK DR", ENDITEM, 
		"Name=CITYTB", "Value={ChangeCity}", ENDITEM, 
		"Name=STATECB", "Value=FL", ENDITEM, 
		"Name=ZIPTB", "Value=34113", ENDITEM, 
		"Name=postFlag", "Value=P", ENDITEM, 
		"Name=ReportLevelCB", "Value=V", ENDITEM, 
		"Name=TrantypCB", "Value=10", ENDITEM, 
		"Name=TranEffDtTB", "Value=20210426", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=PolicyDetail", ENDITEM, 
		"Name=PolicyDetailPgBtn", "Value=ModifyVehicleAll", ENDITEM, 
		"Name=FROMPAGE", "Value=PolicyDetail", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=", ENDITEM, 
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM, 
		"Name=EditValue", "Value=Modify", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		LAST);
//	if(atoi(lr_eval_string("{T_EditCity4}"))>0)
//	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_41_ChangecityAndEditVehicle", LR_PASS);
//	}
//	else
//	{
//		lr_error_message("ALIR_PCG_ReportSelection_FL_41_ChangecityAndEditVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
//		lr_end_transaction("ALIR_PCG_ReportSelection_FL_41_ChangecityAndEditVehicle", LR_FAIL);
//		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
//	}
	lr_think_time(5);

	/* change vehicle make and save vehicle */
	web_reg_find("Search=Body",
		"SaveCount=T_VEdit4",
		"Text=Transaction has been Updated Successfully",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_42_ChangeVehicleMakeAndSaveVehicle");

	web_submit_data("Controller_33", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=PolicyTB", "Value=0080865720", ENDITEM, 
		"Name=LNAMETB", "Value=VOIGT", ENDITEM, 
		"Name=PolEffDtTB", "Value=11/12/2020", ENDITEM, 
		"Name=PolExpDtTB", "Value=11/12/2021", ENDITEM, 
		"Name=TrantypCB", "Value=10", ENDITEM, 
		"Name=TranEffDtTB", "Value=20210426", ENDITEM, 
		"Name=VinTB", "Value=1FMCU0G90EUE07298", ENDITEM, 
		"Name=yearTB", "Value=2014", ENDITEM, 
		"Name=makeTB", "Value={VehicleMake}", ENDITEM, 
		"Name=CovglvlCB", "Value=03", ENDITEM, 
		"Name=FRCaseNoTB", "Value=", ENDITEM, 
		"Name=CertDtTB", "Value=", ENDITEM, 
		"Name=PrepareDtTB", "Value=", ENDITEM, 
		"Name=postFlag", "Value=P", ENDITEM, 
		"Name=beanAlias", "Value=VehicleDetail", ENDITEM, 
		"Name=VehicleDetailPgBtn", "Value=SaveVehicleTransaction", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=UPDUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=POSTUSRID", "Value=U1PVPCG", ENDITEM, 
		"Name=UPDDATE", "Value=20210614", ENDITEM, 
		"Name=POSTDT", "Value=20210614", ENDITEM, 
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM, 
		"Name=SRCDT", "Value=20210614", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=POLICY", "Value=0080865720", ENDITEM, 
		"Name=ENTTYPQ", "Value=1", ENDITEM, 
		"Name=RPTLVL", "Value=V", ENDITEM, 
		"Name=STATE", "Value=FL", ENDITEM, 
		"Name=NONSTRNM", "Value=", ENDITEM, 
		"Name=NAMESFX", "Value=", ENDITEM, 
		"Name=LNAME", "Value=VOIGT", ENDITEM, 
		"Name=FNAME", "Value=HANS-JOACH", ENDITEM, 
		"Name=MNAME", "Value=", ENDITEM, 
		"Name=DOB", "Value=19530528", ENDITEM, 
		"Name=GENDER", "Value=M", ENDITEM, 
		"Name=IDCD", "Value=", ENDITEM, 
		"Name=ADDRESS", "Value=560 EAGLE CREEK DR", ENDITEM, 
		"Name=CITY", "Value={ChangeCity}", ENDITEM, 
		"Name=ZIP", "Value=34113", ENDITEM, 
		"Name=NAIC", "Value=19402", ENDITEM, 
		"Name=RESRC", "Value=", ENDITEM, 
		"Name=POLEFFDT", "Value=20201112", ENDITEM, 
		"Name=POLEXPDT", "Value=20211112", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_VEdit4}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_42_ChangeVehicleMakeAndSaveVehicle", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_42_ChangeVehicleMakeAndSaveVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_42_ChangeVehicleMakeAndSaveVehicle", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* back to source posted */

	web_reg_find("Search=Body",
		"SaveCount=T_SPBack",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_43_BackToSourcePosted");

	web_url("Controller_34", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{T_SPBack}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_43_BackToSourcePosted", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_43_BackToSourcePosted : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_43_BackToSourcePosted", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* select any policy and click delte */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_44_ClickDelete");

	web_submit_data("RemoteScripting_10", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729625735965", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM,
		"Name=TRNNO", "Value=2021-06-09-02.00.32.948348", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM,
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_44_ClickDelete", LR_AUTO);
	lr_think_time(5);


	/* undelete */
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_45_ClickUnDelete");

	web_submit_data("RemoteScripting_11", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729638281894", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.948348", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=D", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM,
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
		
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_45_ClickUnDelete", LR_AUTO);
	lr_think_time(5);

	/* post */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_46_ClickPost");

	web_submit_data("RemoteScripting_12", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729651661556", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value=P", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.948348", ENDITEM, 
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value=P", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM,
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_46_ClickPost", LR_AUTO);
	lr_think_time(5);

	/* unpost */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_47_ClickUnPost");

	web_submit_data("RemoteScripting_13", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729663591668", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.948348", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM,
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_47_ClickUnPost", LR_AUTO);
	lr_think_time(5);

	/* next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_48_ClickNext");

	web_submit_data("Controller_35", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=TransList&TransListPgBtn=&functionName=startup&RECSRC=SRC&chkFlag=SRC2", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
//		"Name=TRNNO", "Value=2021-06-09-02.00.32.943812", ENDITEM, 
		"Name=TRNNO", "Value=2021-06-09-02.00.32.948348", ENDITEM, 
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=2", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.932389", ENDITEM,
		"Name=TRANSERRCODES", "Value=,,,,,,,,,", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_48_ClickNext", LR_AUTO);
	lr_think_time(5);

	/* prev */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_49_ClickPrev");

	web_submit_data("Controller_36", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=PrevRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.916630", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.931894", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.931894", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.916630", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_49_ClickPrev", LR_AUTO);
	lr_think_time(5);

	/* next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_50_ClickNext");

	web_submit_data("Controller_37", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.931894", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.949299", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.931894", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_50_ClickNext", LR_AUTO);
	lr_think_time(5);

	/* first */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_51_ClickFirst");

	web_submit_data("Controller_38", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=TransList", ENDITEM, 
		"Name=TransListPgBtn", "Value=FirstRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-06-09-02.00.32.916121", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-06-09-02.00.32.931036", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-06-09-02.00.32.931036", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-06-09-02.00.32.916121", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=POSTBUTTONFLAG", "Value=Y", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_51_ClickFirst", LR_AUTO);
	lr_think_time(5);

	/* click SR21 state initiated */
	web_reg_find("Search=Body",
		"SaveCount=T_SR21",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_52_ClickSR21StateInitiated");

	web_url("Controller_39", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=SR21TransList&SR21TransListPgBtn=&functionName=startup&RECSRC=MVF&chkFlag=MVF", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{T_SR21}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_52_ClickSR21StateInitiated", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_52_ClickSR21StateInitiated : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_52_ClickSR21StateInitiated", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* select any policy and click edit */
	web_reg_find("Search=Body",
		"SaveCount=T_PEdit5",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_53_ClickEditVehicle");

	web_submit_data("Controller_40", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=SR21TransList&SR21TransListPgBtn=&functionName=startup&RECSRC=MVF&chkFlag=MVF", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=SR21TransList", ENDITEM, 
		"Name=SR21TransListPgBtn", "Value=Edit", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=MVFFLAG", "Value=Y", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{T_PEdit5}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_53_ClickEditVehicle", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_53_ClickEditVehicle : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_53_ClickEditVehicle", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);

	/* back to SR21 */
	web_reg_find("Search=Body",
		"SaveCount=T_SR21Back",
		"Text=Policy No",
		LAST);
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_54_BackToSR21");

	web_url("Controller_41", 
		"URL=https://{P_url}/RRDWeb/Controller?beanAlias=SR21TransList&SR21TransListPgBtn=&functionName=startup&RECSRC=MVF&chkFlag=MVF", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/fl/MenuPg_N.jsp", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{T_SR21Back}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_54_BackToSR21", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_54_BackToSR21 : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_54_BackToSR21", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	lr_think_time(5);


	/* select any policy click delete */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_55_ClickDelete");

	web_submit_data("RemoteScripting_14", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729815777420", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=SR21TransList&SR21TransListPgBtn=&functionName=startup&RECSRC=MVF&chkFlag=MVF", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
//		"Name=TRNNO", "Value=2021-01-15-06.08.58.681897", ENDITEM, 
		"Name=TRNNO", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=P", ENDITEM, 
		"Name=STATUS", "Value=D", ENDITEM, 
		"Name=beanAlias", "Value=SR21TransList", ENDITEM, 
		"Name=SR21TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM,
		"Name=TRANSERRCODES", "Value=", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=MVFFLAG", "Value=Y", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_55_ClickDelete", LR_AUTO);
	lr_think_time(5);


	/* undelete */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_56_ClickUnDelete");

	web_submit_data("RemoteScripting_15", 
		"Action=https://{P_url}/RRDWeb/RemoteScripting?U=1623729833498578", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=SR21TransList&SR21TransListPgBtn=&functionName=startup&RECSRC=MVF&chkFlag=MVF", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=callBack", "Value=jsrs1", ENDITEM, 
		"Name=F", "Value=null", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
//		"Name=TRNNO", "Value=2021-01-15-06.08.58.681897", ENDITEM, 
		"Name=TRNNO", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=D", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=SR21TransList", ENDITEM, 
		"Name=SR21TransListPgBtn", "Value=UpdateStatus", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM,
		"Name=TRANSERRCODES", "Value=", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=MVFFLAG", "Value=Y", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("ALIR_PCG_ReportSelection_FL_56_ClickUnDelete", LR_AUTO);
	lr_think_time(5);

	/* next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_57_ClickNext");

	web_submit_data("Controller_42", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?beanAlias=SR21TransList&SR21TransListPgBtn=&functionName=startup&RECSRC=MVF&chkFlag=MVF", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
//		"Name=TRNNO", "Value=2021-01-15-06.08.58.681897", ENDITEM, 
		"Name=TRNNO", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=CURRENTSTATUS", "Value= ", ENDITEM, 
		"Name=STATUS", "Value= ", ENDITEM, 
		"Name=beanAlias", "Value=SR21TransList", ENDITEM, 
		"Name=SR21TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=1", ENDITEM, 
//		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
//		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
//		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
//		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM,
		"Name=TRANSERRCODES", "Value=", ENDITEM,
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=MVFFLAG", "Value=Y", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_57_ClickNext", LR_AUTO);
	lr_think_time(5);


	/* prev */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_58_ClickPrev");

	web_submit_data("Controller_43", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=SR21TransList", ENDITEM, 
		"Name=SR21TransListPgBtn", "Value=PrevRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-01-14-07.18.13.187487", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-01-15-06.07.12.773195", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-01-15-06.07.12.773195", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-01-14-07.18.13.187487", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=MVFFLAG", "Value=Y", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_58_ClickPrev", LR_AUTO);
	lr_think_time(5);


	/* next */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_59_ClickNext");

	web_submit_data("Controller_44", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=SR21TransList", ENDITEM, 
		"Name=SR21TransListPgBtn", "Value=NextRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-01-15-06.08.58.692204", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-01-15-06.07.12.775709", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=MVFFLAG", "Value=Y", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_59_ClickNext", LR_AUTO);
	lr_think_time(5);


	/* first */

	lr_start_transaction("ALIR_PCG_ReportSelection_FL_60_ClickFirst");

	web_submit_data("Controller_45", 
		"Action=https://{P_url}/RRDWeb/Controller", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=TBSEARCHKEYOPTION", "Value=POLICY", ENDITEM, 
		"Name=search", "Value=", ENDITEM, 
		"Name=TRNNO", "Value=", ENDITEM, 
		"Name=CURRENTSTATUS", "Value=", ENDITEM, 
		"Name=STATUS", "Value=", ENDITEM, 
		"Name=beanAlias", "Value=SR21TransList", ENDITEM, 
		"Name=SR21TransListPgBtn", "Value=FirstRowSet", ENDITEM, 
		"Name=row", "Value=", ENDITEM, 
		"Name=TBSEARCHKEYVALUE", "Value=2021-01-14-07.18.13.187487", ENDITEM, 
		"Name=browsestackvalue", "Value=2021-01-15-06.07.12.773195", ENDITEM, 
		"Name=browsestackKEYvalue", "Value=2021-01-15-06.07.12.773195", ENDITEM, 
		"Name=TBKEYVALUE", "Value=2021-01-14-07.18.13.187487", ENDITEM, 
		"Name=TRANSERRCODES", "Value=", ENDITEM, 
		"Name=transactionNos", "Value=", ENDITEM, 
		"Name=multipleDelete", "Value=", ENDITEM, 
		"Name=multipleMove", "Value=", ENDITEM, 
		"Name=MVFFLAG", "Value=Y", ENDITEM, 
		"Name=POSTFROMLIST", "Value=N", ENDITEM, 
		"Name=firstnext", "Value=", ENDITEM, 
		"Name=pagenumber1", "Value=", ENDITEM, 
		LAST);
	lr_end_transaction("ALIR_PCG_ReportSelection_FL_60_ClickFirst", LR_AUTO);
	lr_think_time(5);


	/* click logoff */
	web_reg_save_param("C_OKTAID","LB=aig-na-ciamuat1_uwalir_1/{C_issuerID}/","RB=\r\n", LAST);
	
	lr_start_transaction("ALIR_PCG_ReportSelection_FL_61_ClickLogoff");
	web_url("LogOffController", 
		"URL=https://{P_url}/RRDWeb/LogOffController?beanAlias=Login&loginBtn=Logoff&functionName=startup", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{P_url}/RRDWeb/Controller?userIDTB=U1PVPCG&userRoleTB=PCG_User&beanAlias=Login&loginBtn=Login", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_url("signout", 
		"URL=https://aig-na-ciamuat1-admin.oktapreview.com/login/admin/signout?fromURI=https%3A%2F%2Fuatauth1.customerpltfm.aig.com%2Fhome%2Faig-na-ciamuat1_uwalir_1%2F{C_issuerID}%2F{C_OKTAID}&fromOktaDomain=false&fromCustomDomain=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uatauth1.customerpltfm.aig.com/login/signout?fromURI=https://uatauth1.customerpltfm.aig.com/home/aig-na-ciamuat1_uwalir_1/{C_issuerID}/{C_OKTAID}", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=https://aig-na-ciamuat1.oktapreview.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);
	
	web_reg_find("Search=Body",
		"SaveCount=T_Logoff",
		"Text=AIG-UAT - Sign In",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=C_Statetoken4",
		"LB=x2Fredirect\\x3FstateToken\\x3D",
		"RB=';}}",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);

	web_url("{C_OKTAID}", 
		"URL=https://uatauth1.customerpltfm.aig.com/home/aig-na-ciamuat1_uwalir_1/{C_issuerID}/{C_OKTAID}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://aig-na-ciamuat1.oktapreview.com/login/signout?fromURI=https%3A%2F%2Fuatauth1.customerpltfm.aig.com%2Fhome%2Faig-na-ciamuat1_uwalir_1%2F{C_issuerID}%2F{C_OKTAID}&fromOktaDomain=false&fromCustomDomain=true&fromAdmin=true", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_save_string(lr_eval_string("{C_Statetoken4}"),"hex_data1_copy4");
			
	lr_save_string(lr_replace("hex_data1_copy4","\\x2D","-"),"C_Statetoken3");

	web_add_header("x-okta-user-agent-extended", 
		"okta-auth-js/5.8.0 okta-signin-widget-5.16.1");

	web_custom_request("introspect_2", 
		"URL=https://uatauth1.customerpltfm.aig.com/api/v1/authn/introspect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uatauth1.customerpltfm.aig.com/signin/refresh-auth-state/{C_Statetoken3}", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"stateToken\":\"{C_Statetoken3}\"}", 
		LAST);
	
	if(atoi(lr_eval_string("{T_Logoff}"))>0)
	{
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_61_ClickLogoff", LR_PASS);
	}
	else
	{
		lr_error_message("ALIR_PCG_ReportSelection_FL_61_ClickLogoff : %s",lr_eval_string("failed for Policy: {PolicyNumber} ,iteration: {Iteration} ,VUser: {vuser}, HOST: {LG} , GROUP: {Group} "));
		lr_end_transaction("ALIR_PCG_ReportSelection_FL_61_ClickLogoff", LR_FAIL);
		lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	

	return 0;
}