# 1 "c:\\users\\chanm\\documents\\sailpoint\\updated scripts\\nid\\sc06_sailpoint_nid_bot_eid_creation\\\\combined_SC06_SailPoint_NID_Bot_EID_Creation.c"
# 1 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"


# 1075 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);
VTCERR   vtc_update_all_message_ifequals(PVCI pvci, char * columnNames, char * message, char * ifmessage, char * delimiter, unsigned short *outRc);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);
VTCERR   lrvtc_update_all_message_ifequals(char * columnNames, char * message, char * ifmessage, char * delimiter);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "c:\\users\\chanm\\documents\\sailpoint\\updated scripts\\nid\\sc06_sailpoint_nid_bot_eid_creation\\\\combined_SC06_SailPoint_NID_Bot_EID_Creation.c" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "c:\\users\\chanm\\documents\\sailpoint\\updated scripts\\nid\\sc06_sailpoint_nid_bot_eid_creation\\\\combined_SC06_SailPoint_NID_Bot_EID_Creation.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\Virtual User Generator\\include/lrw_custom_body.h" 1
 





# 8 "globals.h" 2


 
 


# 3 "c:\\users\\chanm\\documents\\sailpoint\\updated scripts\\nid\\sc06_sailpoint_nid_bot_eid_creation\\\\combined_SC06_SailPoint_NID_Bot_EID_Creation.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 4 "c:\\users\\chanm\\documents\\sailpoint\\updated scripts\\nid\\sc06_sailpoint_nid_bot_eid_creation\\\\combined_SC06_SailPoint_NID_Bot_EID_Creation.c" 2

# 1 "Action.c" 1
Action()
{

	char aSeparator[2];
	char aSeparator1[2];
	char pstr1[100];
	int a,b;
	char pstr2[100]={0};
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_max_html_param_len("9999999"); 
	
	web_cleanup_cookies();
	
	web_cache_cleanup();


	web_set_user("R1-CORE.R1.AIG.NET\\smr", 
		"Sathish@6608", 
		"uatiwaokta.aig.net:443");
	
	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	
	
 
 
	web_reg_save_param_ex(
		"ParamName=C_StateToken1",
		"LB=var stateToken = \"",
		"RB=\";",
		"SEARCH_FILTERS",
		"LAST");
	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_01_Launch");

	web_url("home.jsf", 
		"URL=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"LAST");

	strcpy(pstr1,lr_eval_string("{C_StateToken1}"));
	strcpy(aSeparator,"\\");
	strcpy(aSeparator1,"-");
	
	lr_output_message("%s",pstr1);
 
	pstr2[0]='\0';

	for(a=0,b=0;pstr1[a]!=0;a++,b++)
	{
    if(pstr1[a]==aSeparator[0])
    {
    	pstr2[b]=aSeparator1[0];
        pstr2[b+1]=pstr1[a+4];
        a=a+5;
        b=b+2;
        
       
    }
    pstr2[b]=pstr1[a];
    
    lr_log_message("%s",pstr2);
    
	}

	lr_save_string(lr_eval_string(pstr2), "StateToken");
	
	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"102\", \"Google Chrome\";v=\"102\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_reg_find("Search=Body",
	             "SaveCount=textcheck01",
				"Text=uataigtech - Sign In",
		"LAST");

	web_url("{StateToken}", 
		"URL=https://uataigtech.oktapreview.com/login/interact/{StateToken}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/login/login.htm?fromURI="
		"%2Fapp%2Fsailpointiiq%2Fexknwm9rmiVHZYHEo0h7%2Fsso%2Fsaml%3FSAMLRequest%3DnVNdb9pAEHzvr7Du3R8YaOCEHVFoBFLaInAiNS%252FVcV6Ha%252Bw753YN5N%252F3MCHhoUFVX%252Fd2Zmdn9kbX%252B6r0tmBRGZ2wThAxD7Q0udKPCbvLbvwBu04%252FjVBUZVzzcUMbvYTnBpC8MSJYcriJ0dhUYFdgt0rC3fI2YRuiGnkYqhw0KXpRz42gQKjHQAOdVcONqSD4jQXzpo5UaUGtkhPeoRyIQG4C80SitrBVsAukqUJR1yEKVdZGOTJHBfsnvauGtlL3s4efs68m2lyFiCY8qGfejbES2g0SVogSgXnzacJ%252BQSS7sehKX%252BTF0O9dxQN%252FOJC5D7IvIe%252Bve%252Buo41pxIRDVFt7BiA3MNZLQlLA4imM%252F%252BuzHgyzq826P9zpB"
		"L%252B48MG9hDRlpyi9KH21trOZGoEKuRQXISfLV%252BNstj4OIr49NyGdZtvAXP1YZ8%252B5P8cSHeFxgGvkxkMtc9etglh7z461ie85wmUCcEmbpP%252Bc5Cs9npafL%252Be7I59OFKZV88cZlaXYTC4Kcm2QbaMOpBH0spxN02orK%252FaJt5Y3GGqQqFOQsfJvzepyQt0G7yyTYkzcxVS2swoOJsBeS3iw5b5uUbuElFP9l0MU2yeWB25UPR7QzNj8cBUinM7PCLWIsnYz7m6L09fGD%252Fd6fzz9o%252Bgc%253D%26RelayState%3Dhttps%253A%252F%252Fidentityiquat.aig.net%252Fidentityiq%252Fhome.jsf", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://op1static.oktacdn.com/assets/js/mvc/loginpage/initLoginPage.pack.47db94d2da847bad7e35886ca1ebf00e.js", "Referer=https://uataigtech.oktapreview.com/", "ENDITEM", 
		"LAST");

	web_add_auto_header("Accept", 
		"application/json");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Accept-Language", 
		"en");

	web_add_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_add_header("X-Okta-User-Agent-Extended", 
		"okta-auth-js/6.4.5 okta-signin-widget-6.3.2");

	web_custom_request("introspect", 
		"URL=https://uataigtech.oktapreview.com/api/v1/authn/introspect", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/signin/refresh-auth-state/{StateToken}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"stateToken\":\"{StateToken}\"}", 
		"LAST");

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("iframe.html", 
		"URL=https://login.okta.com/discovery/iframe.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"LAST");
		
	if(atoi(lr_eval_string("{textcheck01}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_01_Launch", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_01_Launch failed for FirstName:%s , LastName:%s , Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_01_Launch", 2);
	}

	
	lr_think_time(10);
	
	 

	 

	web_add_cookie("oktaStateToken={StateToken}; DOMAIN=uataigtech.oktapreview.com");
	
	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_02_Login");
	
	web_add_header("Accept", 
		"application/json, text/javascript, */*; q=0.01");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Okta-XsrfToken", 
		"");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"102\", \"Google Chrome\";v=\"102\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("getimage", 
		"URL=https://uataigtech.oktapreview.com/login/getimage?username=Sathishkumar.Mr%40aig.com", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");

	 

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("devicefingerprint", 
		"URL=https://uataigtech.oktapreview.com/auth/services/devicefingerprint", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_auto_header("Accept", 
		"*/*");

	web_add_auto_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("nonce", 
		"URL=https://uataigtech.oktapreview.com/api/v1/internal/device/nonce", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/auth/services/devicefingerprint", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");

	web_add_auto_header("Accept", 
		"application/json");

	web_add_auto_header("Accept-Language", 
		"en");

	web_add_header("X-Device-Fingerprint", 
		"DggM43WJz9haJJbsLgTkPiruv2rB8K37|9070c8832a73068957ece0d779eef3a74c05246ae3f426c9083df2795406b130|fbda330b6f01b9f5203adb2bcb7cf752");

	web_add_header("X-Okta-User-Agent-Extended", 
		"okta-auth-js/6.4.5 okta-signin-widget-6.3.2");

	web_custom_request("authn", 
		"URL=https://uataigtech.oktapreview.com/api/v1/authn", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"password\":\"Sathish@6608\",\"username\":\"Sathishkumar.Mr@aig.com\",\"options\":{\"warnBeforePasswordExpired\":true,\"multiOptionalFactorEnroll\":true},\"stateToken\":\"{StateToken}\"}", 
		"LAST");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("redirect", 
		"URL=https://uataigtech.oktapreview.com/login/token/redirect?stateToken={StateToken}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	(web_remove_auto_header("Upgrade-Insecure-Requests", "ImplicitGen=Yes", "LAST"));

 
	web_reg_save_param("C_javaxViewState1","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete","LAST");
	
	web_add_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_submit_form("home.jsf_2", 
		"Snapshot=t16.inf", 
		"ITEMDATA", 
		"LAST");

 

	web_add_header("Origin", 
		"https://identityiquat.aig.net");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

 
	web_reg_save_param("C_XSRFTOKEN","LB=Ext.util.Cookies.set('CSRF-TOKEN', '","RB=');","LAST");
	
 
	web_reg_save_param("C_javaxViewState2","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete","LAST");
	
 
	web_reg_save_param("C_CurUserID","LB=SailPoint.CURR_USER_ID = '","RB=';","LAST");
	
	web_submit_data("setTimeZone.jsf", 
		"Action=https://identityiquat.aig.net/identityiq/ui/setTimeZone.jsf", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/ui/setTimeZone.jsf", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=timeZoneForm", "Value=timeZoneForm", "ENDITEM", 
		"Name=timeZoneForm:initializeTimeZoneButton", "Value=", "ENDITEM", 
		"Name=timeZoneForm:initialTimeZoneId", "Value=Asia/Calcutta", "ENDITEM", 
		"Name=timeZoneForm:redirectHash", "Value=", "ENDITEM", 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState1}", "ENDITEM", 
		"LAST");
	
	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("X-XSRF-TOKEN", 
		"{C_XSRFTOKEN}");

	web_url("count", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1618568198287", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");

	 

	web_url("messageCatalog", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/messageCatalog?ad1fcefc336-20200715-171039&lang=en-us", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("home", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/me/home", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"LAST");

	web_reg_find("Search=Body",
		"SaveCount=textcheck02",
		"Text=\"success\"",
		"LAST");

	web_url("myAccessReviews", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/certifications/widgets/myAccessReviews?limit=5&start=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");
	if(atoi(lr_eval_string("{textcheck02}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_02_Login", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_02_Login failed for FirstName:%s , LastName:%s , Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_02_Login", 2);
	}
	
	lr_think_time(10);

	 





	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_03_Click_NID_Management");

	(web_remove_auto_header("X-XSRF-TOKEN", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Origin", 
		"https://identityiquat.aig.net");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	web_reg_save_param("C_javaxViewState3","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete","LAST");

	web_submit_data("home.jsf_3", 
		"Action=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=quickLinksForm", "Value=quickLinksForm", "ENDITEM", 
		"Name=quickLinksForm:quickLink", "Value=AIG-QuickLink-NIDManagement", "ENDITEM", 
		"Name=quickLinksForm:identityId", "Value={C_CurUserID}", "ENDITEM", 
		"Name=quickLinksForm:chooseQuickLinkBtn", "Value=", "ENDITEM", 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState2}", "ENDITEM", 
		"LAST");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("X-XSRF-TOKEN", 
		"{C_XSRFTOKEN}");

	web_url("count_2", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1656507569876", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("common-work-item.jsf", 
		"URL=https://identityiquat.aig.net/identityiq/ui/js/workitem/template/common-work-item.jsf", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("session", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/workItems/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_reg_find("Search=Body",
		"SaveCount=textcheck03",
		"Text=\"NID Management\"",
		"LAST");

	web_url("session_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"LAST");

	if(atoi(lr_eval_string("{textcheck03}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_03_Click_NID_Management", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_03_Click_NID_Management failed for FirstName:%s , LastName:%s , Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_03_Click_NID_Management", 2);
	}
	
	lr_think_time(10);
	
	 





	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_04_Click_Request_Type");

	web_add_auto_header("Origin", 
		"https://identityiquat.aig.net");

	

	web_custom_request("dynamicAllowedValues", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"requestFor\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\"},\"formId\":\"0aa2c5627d941401817d94d42fd00012\",\"query\":\"\",\"limit\":5,\"filterString\":\"\"}", 
		"LAST");

	web_custom_request("postback", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestFor\":\"NID Bot ID Management: Add/Change\"}}", 
		"LAST");


	web_custom_request("dynamicAllowedValues_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"requestType\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestFor\":\"NID Bot ID Management: Add/Change\"},\"formId\":\"0aa2c5627d941401817d94d42fd00012\",\"query\":\"\",\""
		"limit\":5,\"filterString\":\"\"}", 
		"LAST");

	web_custom_request("postback_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestFor\":\"NID Bot ID Management: Add/Change\",\"requestType\":\"BOT NID Creation\"}}", 
		"LAST");


	
	web_reg_find("Search=Body",
		"SaveCount=textcheck04",
		"Text=\"cancelled\":false",
		"LAST");

	web_custom_request("submit", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/submit", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestFor\":\"NID Bot ID Management: Add/Change\",\"requestType\":\"BOT NID Creation\"},\"formId\":\"0aa2c5627d941401817d94d42fd00012\",\"button\":{\""
		"disabled\":false,\"loading\":true,\"action\":\"next\",\"actionParameter\":null,\"actionParameterValue\":null,\"label\":\"Next\",\"skipValidation\":false}}", 
		"LAST");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_url("session_3", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/workItems/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("session_4", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"LAST");

	if(atoi(lr_eval_string("{textcheck04}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_04_Click_Request_Type", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_04_Click_Request_Type failed for FirstName:%s , LastName:%s , Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_04_Click_Request_Type", 2);
	}

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(10);

	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_05_Bot_manager");
	
	web_url("count_3", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1656507870063", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"LAST");

	 

	web_add_auto_header("Origin", 
		"https://identityiquat.aig.net");


	web_reg_find("Search=Body",
		"SaveCount=textcheck05",
		"Text=success",
		"LAST");

	web_custom_request("sailpoint.object.Identity", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/suggest/object/sailpoint.object.Identity", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"assignManager\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":null,\""
		"agreementstatement\":null},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"query\":\"vibhu\",\"limit\":5,\"filterString\":\"(workerType == \\\"Employee\\\" && inactive == false)\",\"extraParams\":{\"context\":\"CustomAttribute\",\"suggestId\":\"AIG-Form-BOTNIDCreation-form-assignManager-field\"}}", 
		"LAST");



	web_custom_request("postback_3", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\"agreementstatement\":null}}", 
		"LAST");

	if(atoi(lr_eval_string("{textcheck05}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_05_Bot_manager", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_05_Bot_manager failed for FirstName:%s , LastName:%s , Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_05_Bot_manager", 2);
	}
	lr_think_time(10);

	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_06_Bot_RPA_GEAR_Name");

	web_reg_find("Search=Body",
		"SaveCount=textcheck06",
		"Text=\"success\"",
		"LAST");

	web_custom_request("dynamicAllowedValues_3", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"appname\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\""
		"manageremployeeId\":\"{Manager_ID}\",\"costcenter\":\"116101021067\",\"agreementstatement\":null},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"query\":\"\",\"limit\":5,\"filterString\":\"\"}", 
		"LAST");

	web_custom_request("postback_4", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\"manageremployeeId\":\""
		"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"agreementstatement\":null}}", 
		"LAST");

	if(atoi(lr_eval_string("{textcheck06}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_06_Bot_RPA_GEAR_Name", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_06_Bot_RPA_GEAR_Name Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_06_Bot_RPA_GEAR_Name", 2);
	}

	lr_think_time(10);

	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_07_Access_Domain");

	web_reg_find("Search=Body",
		"SaveCount=textcheck07",
		"Text=\"success\"",
		"LAST");

	web_custom_request("dynamicAllowedValues_4", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"ADdomain\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\","
		"\"manageremployeeId\":\"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"agreementstatement\":null},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"query\":\"\",\"limit\":5,\"filterString\":\"\"}", 
		"LAST");

	web_custom_request("postback_5", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\"manageremployeeId\":\""
		"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"agreementstatement\":null}}", 
		"LAST");


	
	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	

	web_url("count_4", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1656508172247", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"LAST");
	
		if(atoi(lr_eval_string("{textcheck07}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_07_Access_Domain", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_07_Access_Domain Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_07_Access_Domain", 2);
	}
		
	lr_think_time(10);



	web_add_auto_header("Origin", 
		"https://identityiquat.aig.net");



	web_reg_find("Search=Body",
		"SaveCount=textcheck08",
		"Text=\"success\"",
		"LAST");
	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_08_Click_Location");

	web_custom_request("dynamicAllowedValues_5", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"botcity\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\""
		"manageremployeeId\":\"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"agreementstatement\":null},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"query\":\"\",\"limit\":5,\"filterString\":\"\"}", 
		"LAST");



	web_custom_request("dynamicAllowedValues_6", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"botcity\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\""
		"manageremployeeId\":\"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"agreementstatement\":null},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"query\":\"uj\",\"limit\":5,\"filterString\":\"\"}", 
		"LAST");

	web_custom_request("dynamicAllowedValues_7", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"botcity\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\""
		"manageremployeeId\":\"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"agreementstatement\":null},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"query\":\"uni\",\"limit\":5,\"filterString\":\"\"}", 
		"LAST");

	

	web_custom_request("dynamicAllowedValues_8", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/dynamicAllowedValues", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"fieldName\":\"botcity\",\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\""
		"manageremployeeId\":\"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"agreementstatement\":null},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"query\":\"unit\",\"limit\":5,\"filterString\":\"\"}", 
		"LAST");

	web_custom_request("postback_6", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\"manageremployeeId\":\""
		"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"botcity\":\"UNITED STATES\",\"agreementstatement\":null}}", 
		"LAST");

	if(atoi(lr_eval_string("{textcheck08}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_08_Click_Location", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_08_Click_Location Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_08_Click_Location", 2);
	}

	 

	lr_think_time(10);

	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_09_I_Acknowledge_check_box");

	web_reg_find("Search=Body",
		"SaveCount=textcheck09",
		"Text=\"BOT Creation\"",
		"LAST");

	web_custom_request("postback_7", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/postback", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\"manageremployeeId\":\""
		"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"botcity\":\"UNITED STATES\",\"agreementstatement\":true}}", 
		"LAST");

	if(atoi(lr_eval_string("{textcheck09}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_09_I_Acknowledge_check_box", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_09_I_Acknowledge_check_box Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_09_I_Acknowledge_check_box", 2);
	}

	lr_think_time(10);

	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_10_Click_next");

	web_reg_find("Search=Body",
		"SaveCount=textcheck10",
		"Text={}",
		"LAST");

	web_custom_request("submit_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/submit", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\"manageremployeeId\":\""
		"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"botcity\":\"UNITED STATES\",\"agreementstatement\":true},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"button\":{\"disabled\":false,\"loading\":true,\"action\":\"next\",\"actionParameter\":null,\"actionParameterValue\":null,\"label\":\"Next\",\"skipValidation\":false}}", 
		"LAST");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_url("session_5", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/workItems/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("session_6", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/session", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"LAST");

	if(atoi(lr_eval_string("{textcheck10}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_10_Click_next", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_10_Click_next Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_10_Click_next", 2);
	}
	
	lr_think_time(10);

	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_11_Click_Confirm");

	web_add_auto_header("Origin", 
		"https://identityiquat.aig.net");

	
	web_custom_request("submit_3", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/forms/submit", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"formBeanClass\":\"sailpoint.service.form.TransientFormStore\",\"formBeanState\":{},\"data\":{\"launcherEmployeeNumber\":\"{UserId}\",\"launcherEmail\":\"Sathishkumar.Mr@aig.com\",\"launcherLanID\":\"smr\",\"launcherLocation\":\"Jersey City\",\"launcherManager\":\"Nagrani,Rakhi\",\"launcherDomain\":null,\"employeetype\":\"ContingentWorker\",\"requestType1\":\"BOT NID Creation\",\"firstname\":\"{P_Firstname}\",\"botrequest\":\"testing\",\"assignManager\":\"{Manager_ID}\",\"manageremployeeId\":\""
		"{Manager_ID}\",\"costcenter\":\"116101021067\",\"appname\":\"{Appname}\",\"gearId\":\"{GearID}\",\"ADdomain\":\"R1-Core\",\"botcity\":\"UNITED STATES\",\"agreementstatement\":true},\"formId\":\"0aa2c5627d941401817d94d42f890011\",\"button\":{\"disabled\":false,\"loading\":true,\"action\":\"next\",\"actionParameter\":null,\"actionParameterValue\":null,\"label\":\"Confirm\",\"skipValidation\":false}}", 
		"LAST");

	(web_remove_auto_header("X-XSRF-TOKEN", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	web_reg_save_param("C_javaxViewState4","LB=id=\"j_id1:javax.faces.ViewState:0\" value=\"","RB=\" autocomplete","LAST");

	web_submit_data("commonWorkItem.jsf", 
		"Action=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/workitem/commonWorkItem.jsf", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=transitionForm", "Value=transitionForm", "ENDITEM", 
		"Name=transitionForm:transBtn", "Value=", "ENDITEM", 
		"Name=transitionForm:messages", "Value=", "ENDITEM", 
		"Name=transitionForm:outcome", "Value=viewHome", "ENDITEM", 
		"Name=transitionForm:fallback", "Value=viewHome", "ENDITEM", 
		"Name=transitionForm:back", "Value=false", "ENDITEM", 
		"Name=transitionForm:navigationHistory", "Value=", "ENDITEM", 
		"Name=transitionForm:noFlow", "Value=undefined", "ENDITEM", 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState3}", "ENDITEM", 
		"LAST");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("X-XSRF-TOKEN", 
		"{C_XSRFTOKEN}");

	web_url("count_5", 
		"URL=https://identityiquat.aig.net/identityiq/rest/workItemNotifications/count?_dc=1656508332340", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("messageCatalog_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/messageCatalog?525e3cd5e39-20211021-133519&lang=en-us", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("home_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/me/home", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"LAST");

	web_reg_find("Search=Body",
		"SaveCount=textcheck11",
		"Text=\"success\"",
		"LAST");

	web_url("myAccessReviews_2", 
		"URL=https://identityiquat.aig.net/identityiq/ui/rest/certifications/widgets/myAccessReviews?limit=5&start=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		"LAST");
	if(atoi(lr_eval_string("{textcheck11}"))==0)
	{
		lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_11_Click_Confirm", 1);
		
		lr_error_message("SC06_SailPoint_NID_Bot_EID_Creation_11_Click_Confirm failed for Itertion Number :%s , Time: %s , Load Generator: %s ",lr_eval_string("{P_IterationNumber}"),lr_eval_string("{P_Time}"),lr_eval_string("{P_LGName}"));
		
		lr_exit(2,1);
	}
	else{
		
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_11_Click_Confirm", 2);
	}
	
	lr_start_transaction("SC06_SailPoint_NID_Bot_EID_Creation_12_click_logout");

	web_submit_data("home.jsf_4", 
		"Action=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=headerForm", "Value=headerForm", "ENDITEM", 
		"Name=headerForm:id", "Value=", "ENDITEM", 
		"Name=headerForm:logoutButton", "Value=", "ENDITEM", 
		"Name=javax.faces.ViewState", "Value={C_javaxViewState4}", "ENDITEM", 
		"LAST");

	(web_remove_auto_header("Upgrade-Insecure-Requests", "ImplicitGen=Yes", "LAST"));

	web_add_header("Origin", 
		"https://uataigtech.oktapreview.com");

	web_submit_data("home.jsf_5", 
		"Action=https://identityiquat.aig.net/identityiq/home.jsf", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://uataigtech.oktapreview.com/app/sailpointiiq/exknwm9rmiVHZYHEo0h7/sso/saml?SAMLRequest={C_Saml}&RelayState=%2Fidentityiq%2Fhome.jsf", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=SAMLResponse", "Value={c_Saml2}", "ENDITEM", 
		"Name=RelayState", "Value=/identityiq/home.jsf", "ENDITEM", 
		"LAST");	
	
	lr_end_transaction("SC06_SailPoint_NID_Bot_EID_Creation_12_click_logout",2);

	return 0;
}
# 5 "c:\\users\\chanm\\documents\\sailpoint\\updated scripts\\nid\\sc06_sailpoint_nid_bot_eid_creation\\\\combined_SC06_SailPoint_NID_Bot_EID_Creation.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 6 "c:\\users\\chanm\\documents\\sailpoint\\updated scripts\\nid\\sc06_sailpoint_nid_bot_eid_creation\\\\combined_SC06_SailPoint_NID_Bot_EID_Creation.c" 2

