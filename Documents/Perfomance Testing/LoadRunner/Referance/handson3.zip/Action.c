Action()
{
 	
    
	web_url("favicon.ico", 
		"URL=http://www.bing.com/favicon.ico", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_add_cookie("__cfduid=d2ff5064b4bcce59d3a1c9a928515f0091616508189; DOMAIN=opencart.com");

	web_add_cookie("_ga=GA1.2.1993484451.1616564140; DOMAIN=opencart.com");

	web_add_cookie("_gid=GA1.2.771110915.1616564140; DOMAIN=opencart.com");

	web_add_cookie("currency=USD; DOMAIN=www.opencart.com");

	web_add_cookie("__cfduid=d2ff5064b4bcce59d3a1c9a928515f0091616508189; DOMAIN=www.opencart.com");

	web_add_cookie("_ga=GA1.2.1993484451.1616564140; DOMAIN=www.opencart.com");

	web_add_cookie("_gid=GA1.2.771110915.1616564140; DOMAIN=www.opencart.com");

	web_url("opencart.com", 
		"URL=https://opencart.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.opencart.com/application/view/stylesheet/fonts/SourceSansPro-Regular.ttf", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.opencart.com/application/view/javascript/fontawesome/fonts/fontawesome-webfont.eot?", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.opencart.com/application/view/stylesheet/fonts/opencart.eot?h4wsna", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.opencart.com/favicon.ico", "Referer=", ENDITEM, 
		"Url=https://www.googletagmanager.com/gtag/js?id=UA-1988725-1&l=dataLayer&cx=c", "Referer=https://www.opencart.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", "Referer=https://www.opencart.com/", ENDITEM, 
		LAST);

	web_custom_request("collect", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j88&a=265244990&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2F&ul=en-us&de=utf-8&dt=OpenCart%20-%20Open%20Source%20Shopping%20Cart%20Solution&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQAAAAAAC~&jid=765459320&gjid=551487961&cid=1993484451.1616564140&tid=UA-1988725-1&_gid=771110915.1616564140&_r=1&gtm=2ou3h0&z=1014965419", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.opencart.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	web_add_cookie("SRCHUSR=DOB=20210317; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MUID=1CC9B10D1AD565A23165BEF01B656492; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=8FD409CBE2B04AE5BA0A383140AF219B&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANGV2=en; DOMAIN=iecvlist.microsoft.com");

/*	web_url("iecompatviewlist.xml",
		"URL=https://iecvlist.microsoft.com/IE11/1479242656000/iecompatviewlist.xml", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);*/

	/* marketplace */

	web_add_cookie("_gat_gtag_UA_1988725_1=1; DOMAIN=www.opencart.com");

	web_url("index.php", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j88&a=470078300&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension&ul=en-us&de=utf-8&dt=OpenCart%20-%20Marketplace&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQ~&jid=&gjid=&cid=1993484451.1616564140&tid=UA-1988725-1&_gid=771110915.1616564140&gtm=2ou3h0&z=1372723595", "Referer=https://www.opencart.com/index.php?route=marketplace/extension", ENDITEM, 
		"Url=/application/view/image/banner/extensions.jpg", "Referer=https://www.opencart.com/index.php?route=marketplace/extension", ENDITEM, 
		LAST);

	/* search */
	//extension&amp;filter_search=payment&amp;page=2">2</a>
	web_reg_save_param("c_page","LB=filter_search={p_item}&amp;page=","RB=\">","Ord=ALL",LAST);

	web_url("index.php_2", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension&filter_search={p_item}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/application/view/image/banner/extensions.jpg", "Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search={p_item}", ENDITEM, 
		LAST);

	web_custom_request("collect_2", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j88&a=113618605&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension%26filter_search%3D{p_item}&ul=en-us&de=utf-8&dt=OpenCart%20-%20Marketplace&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQAAAAAAC~&jid=1711872586&gjid=748605580&cid=1993484451.1616564140&tid=UA-1988725-1&_gid=771110915.1616564140&_r=1&gtm=2ou3h0&z=1902119053", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search={p_item}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	lr_save_string(lr_paramarr_random("c_page"),"c_randompage");

	/* page */
	//;extension_id={c_randomID}&amp;filter_search=payment
	web_reg_save_param("c_extensionID","LB=extension_id=","RB=&amp;filter_search={p_item}","Ord=ALL",LAST);

	web_url("index.php_3", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension&filter_search={p_item}&page={c_randompage}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search={p_item}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/application/view/image/banner/extensions.jpg", "Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search={p_item}&page={c_randompage}", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j88&a=1017694121&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension%26filter_search%3D{p_item}%26page%3D4&ul=en-us&de=utf-8&dt=OpenCart%20-%20Marketplace&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQ~&jid=&gjid=&cid=1993484451.1616564140&tid=UA-1988725-1&_gid=771110915.1616564140&gtm=2ou3h0&z=1581985371", "Referer=https://www.opencart.com/index.php?route=marketplace/extension&"
		"filter_search={p_item}&page={c_randompage}", ENDITEM, 
		LAST);

	/* extension item */
	lr_save_string(lr_paramarr_random("c_extensionID"),"c_randomID");
	/*cost*/
	//<div class="col-xs-7 text-right">$20.00</div>
	//<title>OpenCart - Peach Payment</title>
	web_reg_save_param("c_price","LB=class=\"col-xs-7 text-right\">$","RB=</div>","Ord=1","NotFound=Warning",LAST);
	web_reg_save_param("c_title","LB=<title>OpenCart - ","RB=</title>","Ord=1","NotFound=Warning",LAST);

	web_url("Process online {p_item}s with Visa and Mastercard, Debit Orders, EFT {p_item}s, recurring billing and multi-currency connected by Opencart. Making {p_item} accepting easy for sellers. Admin Link - Click Here Frontend Link - Click Here..", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension&filter_search={p_item}&page={c_randompage}", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/application/view/javascript/lightbox/images/next.png", "Referer=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", ENDITEM, 
		LAST);

	web_custom_request("collect_3", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j88&a=1568716246&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension%2Finfo%26extension_id%3D{c_randomID}%26filter_search%3D{p_item}%26page%3D4&ul=en-us&de=utf-8&dt=OpenCart%20-%20Peach%20Payment&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQAAAAAAC~&jid=469716105&gjid=1577561995&cid=1993484451.1616564140&tid=UA-1988725-1&_gid=771110915.1616564140&_r=1&gtm=2ou3h0&z=1366860503", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		EXTRARES, 
		"Url=https://www.opencart.com/application/view/javascript/lightbox/images/loading.gif", "Referer=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", ENDITEM, 
		LAST);

	web_url("index.php_4", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension/comment&extension_id={c_randomID}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/application/view/javascript/lightbox/images/close.png", "Referer=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", ENDITEM, 
		"Url=/application/view/javascript/lightbox/images/prev.png", "Referer=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", ENDITEM, 
		LAST);

	/* marketplace */

	web_url("index.php_5", 
		"URL=https://www.opencart.com/index.php?route=marketplace/extension", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id={c_randomID}&filter_search={p_item}&page={c_randompage}", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/application/view/image/banner/extensions.jpg", "Referer=https://www.opencart.com/index.php?route=marketplace/extension", ENDITEM, 
		LAST);

	web_custom_request("collect_4", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j88&a=771579716&t=pageview&_s=1&dl=https%3A%2F%2Fwww.opencart.com%2Findex.php%3Froute%3Dmarketplace%2Fextension&ul=en-us&de=utf-8&dt=OpenCart%20-%20Marketplace&sd=24-bit&sr=1366x628&vp=1349x533&je=1&fl=11.9%20r900&_u=AACAAUQAAAAAAC~&jid=797193511&gjid=39123010&cid=1993484451.1616564140&tid=UA-1988725-1&_gid=771110915.1616564140&_r=1&gtm=2ou3h0&z=681062182", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.opencart.com/index.php?route=marketplace/extension", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);
	/**********file code***********/
	if(strcmp(lr_eval_string("{c_price}"),lr_eval_string(""))!=0)
	{
		if((atoi(lr_eval_string("{c_price}"))<50)){
		   	fprintf(file,"%s -", lr_eval_string("{c_title}"));
			fprintf(file,"%s\n", lr_eval_string("{c_price}"));
		}
	}
	else
	{
		fprintf(file,"%s -", lr_eval_string("{c_title}"));
		fprintf(file,"%s\n", "FREE");
	}

	/* close */

	return 0;
}