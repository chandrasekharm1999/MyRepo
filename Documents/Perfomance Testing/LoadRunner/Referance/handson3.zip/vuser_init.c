vuser_init()
{
	note = "price.txt";
	if((file = fopen(note,"w+"))==NULL){
		lr_error_message("cannot open %s",note);
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_AUTO);
	}
	return 0;
}
