vuser_end()
{
	fclose(file);
	return 0;
}
