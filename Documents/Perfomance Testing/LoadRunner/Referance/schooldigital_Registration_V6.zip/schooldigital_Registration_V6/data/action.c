Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=92", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("NID=219=n9KldUaN7RrRl9sIyrPtcSUO5zonX4O1AtuaRvuQmaPAOsNNGmr-psRME3dTCiTnekta4qA8ymW1AEz4qMdqql2PshjyCpJ58lDY6bSrg26MKYUM92b5IDnH-iN7woCqRlmhOg6Lm0nyOqz5IjFy3EUdUlq96Gmfnn9mo-xWLwM; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2021-07-27-05; DOMAIN=accounts.google.com");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_add_cookie("visid_incap_2409784=P9BVSVJvT3GFZRs5JB8Cr6jU7mAAAAAAQUIPAAAAAACKFZbBu53BeVQKsOidb2bV; DOMAIN=lynxd.aig.co.jp");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"92\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"92\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_url("schoolAuth", 
		"URL=https://lynxd.aig.co.jp/Schoolservice/dist/school/uiuxServices/schoolAuth?orgCode=97001294&subOrgCode=97001294&agencyCode=FB19X8&fiscalYr=2021&regId=0000000000001495", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_cookie("___utmvc=q5jb3wNWltoebRcOn1Z1/56BxeG0VCgohBoTv8M9+EV9Z9XtsrpCMbwNDMEC5OfNN/KoFSw6HtCrzKWnTMhe1MMKu7HegNnQB1lK3dVxRn2VmWslw0f/+WoeLBD7AVwB0HANQEiGuZHdK1G8zRUPhtw6IyYC6UKtiitJaCpL75EMGIsHyALfMGa+xq9z8tEK1NquU/hQsOPgtexDhPTtWibocC9hOqnf3mQNNMsZb8E1nvPV5BJxfJKqxSZM5x9EEKfB5y781S7Z4aeTGfkH/asYaapRZRTKmLB/UbAu49VYGQG/HZHpRpfVPq/PgRDMnnat7xAENDJYI30O6E/DkxrbRtkkV8gQmGxW8Ld7vqUKTlv79Ur9T/wKk6zV0tvxbNG0+elKYg1MOx5unfUg9uk+Ctk6yX2Of6n4EmhIyL7LCRQH83TlMWxJRYhJ432mhTSxSeMDpx84Kt5uJ7+"
		"NwkT4iS7lPQ2dXWaH6TPIml/FnXP5+XVi/VCgF9mhk3xkgq4OkS3fHtlifROXCJTm25sPoLkIjvFttkfZiG/VB9ZcewF6SUWhpFamMc70IRBuSXuxWz/7QceLLyR1JgLGlIGjAaXKdCPI9o3+ZR/BK8IFHsH8qYWRkPEEJptXfRFOs7aQ/i33tAjiYsS3XOktQ5pFw5JiSvQmmSLoZng7NBreaYWUMgz8Cakjt6/HU2hQi6StHzA3bEEMA16PjI+WbS5wE152B0a2eltEUVEv9/77Kyb3r7ri8nbSqiDy3xLCCalO85lwp+Mz/Wa0ElPZj2NVe1rA87aKArjEfFlAzxuTzUquP6yZc/znEWNsvsVAoyCo8QXcyCbmET0EIce43FfNVps6v4AqVduJdLXszaCGvz+r5A/Qm2qtmWQ0wPivRRp/QpA4A58Hw5u6u1m4qZc2VdJSL/"
		"F4AMjHz6K4lwO53BZRl8VKfNDF6VAxXoi8KB28UBSRr2kJEmUWHHBB6g60Yk5uKovul9KgZ367232KyRjrhgIvPXgc9TrYGpmYDD7OLiKxFKGzPRl+KPVH+egHee8kaabMSvNbMele3x+/KKb9vTB8bbTkq3eXAm1ndGHcbQw/99DpJ0XrdmX1XOAJ8y3y+MAde2DLa4loFyjxCZrSo4NpACAjdPCcqvfHvYM7594JX4A8dXgQpNn0AJ6ZV7mYkHpPG69Pk4c9c2AE375zlQvXFlxLXtmFkVdxJSPNNqHvYgrvWwnOkGhF6Vy4e/Ds8XDgpSEC1+oG6nb1R/hxs5zoHrmunNPFziXhsm7n5ckCfdXua2EJelg0V/Jx5SQHoHJJPl91EtXRXIHfoyCIEvkAf30DAQ/BtQNfE5GCMEYAHswqUXX924jKhesz3uUly9fI3Gek81LAjqeoUnJMvXgUt9OmANunOAVgSlJjKWsooPSgk/"
		"UVQd0kcnUBMgRNEXBqgaLrVGThiGcaX4M0fc5Fcl/BBOn3C80L+mx6zHmoRj+N5Hc3vI72cqyRj121LTwYrZ+AWuPwPFOU9RlPQi9UnjgrP19oYdlNRFd21jBxvrAr3xRKcJxGo5z7BE6tS/ckgps2dFSiVUU95v4LqjOUFXJhRiD929hOHu4+pXDyTHxG6UpBL4VOC78WDwDAlfNXhAw5YyOPDA8ahkt/0SIKVXExC37BU/hrDmlgjXod+BhL1TaHA1R3LXYPr4+u01sbjYJJHICohJEvfMUCmNxNP2qVMfXz3LHjlISgnp3YLac1hv5gtCYfG9/q2bPInjl4yleBwVu+U8sWjVhQRtZuBxL+SjHM5wfp3uU2mUVOrmk4wo1Nr2XTvEiECXLTnmC8xeHFeq949cRt3KVAqOBUIia/ghf+bIlpjcO87d10Wc/epCSa7HZDMZiRFTFR36FZoU/"
		"Fq3WpInF7uj1k8YIXgNqg4CYSh2v9ntGLbFE1NaOJP9vpUfYoSbMLeWBqmpKePJ7s4t/teoQi9C+mgpNHZMhYnCKesSEvE+iOMNtiImO6v5E5EyZOjIEXUEzfhB82WEeoh4HO1GpKPD1kyBjGcUivd/osZGlnZXN0PTEzOTgyMixzPWEyNzQ2ZDZkN2VhOTdkOGI5MzdiODk3YjllN2M5YzZiYTA5ODk3NzU2NDZkOWNhNGE2YWM2ZGE2NzY4MDYyODhhOTg3YTk3NTk1ODQ3Njc1; DOMAIN=lynxd.aig.co.jp");

	web_add_header("Origin", 
		"chrome-extension://jlhmfgmfgeifomenelglieieghnjghma");

	web_add_header("appId", 
		"65014E32-67C8-4698-9D92-9528BE74F65A");

	web_add_header("appName", 
		"Cisco-WebEx-Extension");

	web_add_header("confId", 
		"00000000");

	web_add_header("metricsTicket", 
		"YzJWakxYUjNjeTF3Y205a0xYWnBjQzUzWldKbGVDNWpiMjA9");

	web_add_header("siteId", 
		"000000");

	web_add_header("timeStamp", 
		"1627365629195");

	web_add_header("ver", 
		"2.0");

	web_custom_request("v1", 
		"URL=https://sec-tws-prod-vip.webex.com/metric/v1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"telemetrics\":[{\"t\":\"PageView\",\"ts\":\"2021-07-27T11:30:29.196+0550\",\"tid\":\"3bbf9ee1-fa6f-dfbf-c764-70328e20afcb\",\"cid\":\"0670126c-240c-f447-5aea-80c1baddb3e1\",\"pd\":\"unknown\",\"ver\":\"2.0\",\"v\":{\"title\":\"\",\"location\":\"chrome-extension://jlhmfgmfgeifomenelglieieghnjghma/_generated_background_page.html\"}}]}", 
		EXTRARES, 
		"Url=https://lynxd.aig.co.jp/_Incapsula_Resource?SWKMTFSR=1&e=0.905896896370413", "Referer=https://lynxd.aig.co.jp/Schoolservice/dist/school/uiuxServices/schoolAuth?orgCode=97001294&subOrgCode=97001294&agencyCode=FB19X8&fiscalYr=2021&regId=0000000000001495", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Chromium\";v=\"92\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"92\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_url("SchoolDigital", 
		"URL=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://lynxd.aig.co.jp/Schoolservice/dist/school/uiuxServices/schoolAuth?orgCode=97001294&subOrgCode=97001294&agencyCode=FB19X8&fiscalYr=2021&regId=0000000000001495", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=runtime-es2015.deee98928ca63b02c754.js", ENDITEM, 
		"Url=polyfills-es2015.e62c4427aebe641d0773.js", ENDITEM, 
		"Url=SourceSansPro-Regular.c2b23b36ce51dfd4d60a.ttf", "Referer=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/styles.5424f490b4fa36bba555.css", ENDITEM, 
		"Url=main-es2015.ab6520012b5e800ab518.js", ENDITEM, 
		"Url=assets/documents/%E6%9C%80%E7%B5%82_KE-2110%E9%87%8D%E8%A6%81%E4%BA%8B%E9%A0%85%E8%AA%AC%E6%98%8E%E6%9B%B82021.pdf", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Goog-Update-AppId", 
		"blicmleglokdleipjpnnikhmgnkbcoma,jlhmfgmfgeifomenelglieieghnjghma,nmmhkkegccagdldgiimedpiccmgmieda,pkedcjkdefgpdelpbcmbmeomcjbeemfm,ppnbnpeolgkicgegkbkbjmhlideopiji");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-92.0.4515.107");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=11:1648791365&cup2hreq=2e62514b7578251caafd8079f51f009f3deedd40099c3251c7e1a37db704d4e9", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"blicmleglokdleipjpnnikhmgnkbcoma\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"policy\",\"packages\":{\"package\":[{\"fp\":\"2.2020.1.30.1\"}]},\"ping\":{\"ping_freshness\":\"{3d007351-557f-487c-9b76-530d75faaa8c}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"2020.1.30.1\"},{\"appid\":\"jlhmfgmfgeifomenelglieieghnjghma\",\"brand\":\"GCEA\",\"cohort\":\"1"
		"::\",\"enabled\":true,\"installedby\":\"policy\",\"packages\":{\"package\":[{\"fp\":\"1.01cde224a01bebe44fa9d48e97b4f97eb26aa1822f65b77eb23592e7e80ce4df\"}]},\"ping\":{\"ping_freshness\":\"{afd06baf-8c99-4491-9cf6-f141209e203b}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"1.15.0\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\""
		"{1dba5f9d-b74e-4b69-8d4a-3c7b9053c12e}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"1.0.0.6\"},{\"appid\":\"pkedcjkdefgpdelpbcmbmeomcjbeemfm\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"1.9107e42f7f892fecd9a0a8cb05fedae7d9e045442fb17af11a77f6f7253b66b7\"}]},\"ping\":{\"ping_freshness\":\"{23ae979f-82f2-4d2c-adf2-03a8ce4ef8ac}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"9221.427.0.1\"},{\"appid\":\""
		"ppnbnpeolgkicgegkbkbjmhlideopiji\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"policy\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.4\"}]},\"ping\":{\"ping_freshness\":\"{5f241cfa-f3d3-4c16-a9c4-457592540c85}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"1.0.4\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":8},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\""
		"10.0.18363.1679\"},\"prodversion\":\"92.0.4515.107\",\"protocol\":\"3.1\",\"requestid\":\"{5f0d5547-b0ef-41aa-8bbb-5d5ec2fe4c0b}\",\"sessionid\":\"{14b64cc0-dde5-4554-8c66-ded419330ee0}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":1,\"version\":\"1.3.36.92\"},\"updaterversion\":\"92.0.4515.107\"}}", 
		EXTRARES, 
		"Url=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/SourceSansPro-Bold.66dc68e4e7cdfceb5627.ttf", "Referer=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/styles.5424f490b4fa36bba555.css", ENDITEM, 
		LAST);

	web_add_cookie("NID=219=n9KldUaN7RrRl9sIyrPtcSUO5zonX4O1AtuaRvuQmaPAOsNNGmr-psRME3dTCiTnekta4qA8ymW1AEz4qMdqql2PshjyCpJ58lDY6bSrg26MKYUM92b5IDnH-iN7woCqRlmhOg6Lm0nyOqz5IjFy3EUdUlq96Gmfnn9mo-xWLwM; DOMAIN=translate.google.com");

	web_add_cookie("1P_JAR=2021-07-27-05; DOMAIN=translate.google.com");

	web_url("l", 
		"URL=https://translate.googleapis.com/translate_a/l?client=chrome&hl=en&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/SourceSansPro-SemiBold.26160fac3621d82c2431.ttf", "Referer=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/styles.5424f490b4fa36bba555.css", ENDITEM, 
		"Url=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/custom-icons.9e04c4d239d1b9d020ef.ttf", "Referer=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/styles.5424f490b4fa36bba555.css", ENDITEM, 
		"Url=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/SourceSansPro-Light.9fb307e32869e9835cf4.ttf", "Referer=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/styles.5424f490b4fa36bba555.css", ENDITEM, 
		"Url=element.js?cb=cr.googleTranslate.onTranslateElementLoad&aus=true&clc=cr.googleTranslate.onLoadCSS&jlc=cr.googleTranslate.onLoadJavascript&hl=en&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		"Url=../translate_static/js/element/main.js", "Referer=https://lynxd.aig.co.jp/", ENDITEM, 
		"Url=https://translate.google.com/gen204?nca=te_li&client=te_lib&logld=vTE_20210503_00", "Referer=https://lynxd.aig.co.jp/", ENDITEM, 
		LAST);

	/* landed */

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,oimompecagnajdejgnnjijobebaeigek,hnimpnehoodheedghdeeijklkeaacbdc,gcmjkmgdlgnkkcocmoeiminaijmmjnii,cmahhnpholdijhjokonmfdjbfmklppij,obedbbhbpmojnkanicioggnmelmoomoc,lmelglejhemejginpboagddgdfbepgmp,kiabhabjdbkjdpjbpigfodbdjmbglcoo,giekcmmlnklenlaomppkphknjmnnpneh,khaoiebndkojlmppeemjhbpbandiljpe,dhlpobdgcjafebgbbhjdnapejmpkgiie,hfnkpimlhhgieaddgfemjhofmfblmnib,llkgjffcdpffmhiakmfcdcblohccpfmo,aemomkdncapdnfajjbbcbdebjljbpmpj,ehgidpndbllacpjalkiimkbadgjfnnmc,"
		"jflookgnkcckhobaglndicnbbgbonegd,ggkkehgbnfjpeggfpleeakpidbkibbmn,jamhcnnkihinmdlkakkaopbjbbcngflc,ojhpjlocmbogdgmfpkhlaaeamibhnphh,pdafiollngonhoadbmdoemagnfpdphbe,imefjhfbkmcmebodilednhmaccmincoa,eeigpngbgcognadeebkilcpcaedhellh");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-92.0.4515.107");

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=11:2721113748&cup2hreq=95536f5d1e5a2299026deff644edeb0a904f5854ef51e8b598c64dacdfc434a9", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{d7f3e658-4b18-46f6-85c0-b20c5a04674f}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{535845dc-d661-496b-9e23-ad1e0f036669"
		"}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"4.10.2209.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{7c448f45-465b-45e6-a9b0-c68c4348bd32}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GCEA\",\"cohort\":\"1:bm1/1089"
		":\",\"cohorthint\":\"TenPercent_9_28\",\"cohortname\":\"TenPercent_9_28\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.91ee417000553ca22ed67530545c4177a08e7ffcf602c292a71bd89ecd0568a5\"}]},\"ping\":{\"ping_freshness\":\"{fb48b3b9-d705-4ebb-8d29-42f04a3a66ab}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"9.28.0\"},{\"appid\":\"cmahhnpholdijhjokonmfdjbfmklppij\",\"brand\":\"GCEA\",\"cohort\":\"1:wr3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\""
		"package\":[{\"fp\":\"1.b4ddbdce4f8d5c080328aa34c19cb533f2eedec580b5d97dc14f74935e4756b7\"}]},\"ping\":{\"ping_freshness\":\"{0ae1f2e8-2ab6-4b84-b2e4-fef3dae1709e}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"1.0.6\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GCEA\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.811b11bba9f68f317174ed22daad4375950f6cf2b8ba5f0b1e6406b558246097\"}]},\"ping\":{\"ping_freshness\":\"{cd67d3e9-87ca-4cae-b6b2-2bbf150e0227}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"20210721.386679701\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GCEA\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.0e5157ab4741e41f4449cd35404256faf1279f4e653f843d932671f3dbb02dc4\"}]},\"ping\":{\"ping_freshness"
		"\":\"{6c742ad3-c535-4096-8d0e-936aadc3dd29}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"290\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GCEA\",\"cohort\":\"1:v3l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.7c3e0bb573aaba624b6edc230d73d735eb3d952b780781a403317d3ec5b0081b\"}]},\"ping\":{\"ping_freshness\":\"{a25bc294-5f6e-42a8-8b1f-8b22f39b72a4}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"2021.7.27.1\"},{\""
		"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEA\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{97823cfc-6e3e-4910-afa0-15b1e0f792c9}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEA\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ffd1d2d75a8183b0a1081bd03a7ce1d140fded7a9fb52cf3ae864cd4d408ceb4\"}]},\"ping\":{\"ping_freshness\":\"{de249ad7-8502-4992-8427-f26ca93fbcdd}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"43\"},{\"appid\":\"dhlpobdgcjafebgbbhjdnapejmpkgiie\",\"brand\":\"GCEA\",\"cohort\":\"1:z9x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.3eeded944371798374de67d1fa7bb8f32f90a7cd502b04ee71e0de0cf79e2a11\"}]},\"ping\":{\"ping_freshness\":\"{591a9d77-1ec4-475e-860a-902a00d1aad6}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"20210609.1\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEA\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3daae0e074a90f765e56eea1d4e65a04fd6907a3120dee10d753da121b8def98\"}]},\"ping\":{\"ping_freshness\":\""
		"{8aba24f3-3967-488e-9f84-2a66497092af}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"6754\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.2731bdeddb1470bf2f7ae9c585e7315be52a8ce98b8af698ece8e500426e378a\"}]},\"ping\":{\"ping_freshness\":\"{f9a12e70-6b8d-4516-b103-4df20c242f0a}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"1.0.0.8\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"GCEA\""
		",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{c0a7242a-19a1-41f1-b99d-1cb14eb07a4d}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEA\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\""
		"{c7201ff6-3718-423d-806e-ce64dcdfce8a}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GCEA\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.bcd6ef89dc20a049989abd78a38edcb0e32a34663ad9d7223860ebdf2eff61a6\"}]},\"ping\":{\"ping_freshness\":\"{233c78ec-7abf-40cc-8476-4cabec289576}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"2661\"},{\"appid\":"
		"\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GCEA\",\"cohort\":\"1:ut9:\",\"cohorthint\":\"M80ToM99\",\"cohortname\":\"M80ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.74566c4cadcd80a841c10f0636c336a7bb1b94f31a05d7e45ae8b385bfbf53ff\"}]},\"ping\":{\"ping_freshness\":\"{9f9edb14-ce11-4710-8b5c-85178b7ba7df}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"2021.7.19.1143\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GCEA\",\"cohort\":\"1:wvr:\",\"cohorthint\":\""
		"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a76cdce1c1cd7303a553d24d72b1d15dc2c3cc4f405ca649f4abf15dde311551\"}]},\"ping\":{\"ping_freshness\":\"{94b5ccb3-455f-4907-9aa6-098157c769b3}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"94.0.4588.0\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GCEA\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.478aa915e78878e332a0b4bb4d2a6fb67ff1c7f7b62fe906f47095ba5ae112d0\"}]},\"ping\":{\"ping_freshness\":\"{a120518c-4c3b-4fb2-88d8-24de2c81c0dd}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"1\"},{\"appid\":\"pdafiollngonhoadbmdoemagnfpdphbe\",\"brand\":\"GCEA\",\"cohort\":\"1:vz3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.baeb7c645c7704139756b02bf2741430d94ea3835fb1de77fef1057d8c844655\"}]},\"ping\":{\"ping_freshness\":\""
		"{c7455d46-dbea-41f9-a86a-334078814bcb}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"2021.2.22.1142\"},{\"appid\":\"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"GCEA\",\"cohort\":\"1:zor:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.58e200da225ccbe9590ed1dddfa8532dfb61a457cce7c7a38e522c98d1d36448\"}]},\"ping\":{\"ping_freshness\":\"{fd2f23ee-725c-4da6-8e72-dcaf39ce1502}\",\"rd\":5320},\"tag\":\"default\",\"updatecheck\":{},\"version"
		"\":\"25\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GCEA\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{781f3464-ddb8-4b59-8d65-96aa70d004f0}\",\"rd\":5320},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":8},\"lang"
		"\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.18363.1679\"},\"prodversion\":\"92.0.4515.107\",\"protocol\":\"3.1\",\"requestid\":\"{bd48b4ff-7f43-4337-8ebe-6d7bbbe4c4f0}\",\"sessionid\":\"{7c60b4fa-9955-4719-a29f-a1be062feaaf}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":1,\"version\":\"1.3.36.92\"},\"updaterversion\":\"92.0.4515.107\"}}", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINOTIuMC40NTE1LjEwNxopCAUQARobCg0IBRAGGAEiAzAwMTABELnxCxoCGANYpTlvIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARC2nAkaAhgD9wuCGiIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQifUIGgIYA4aPjOYiBCABIAIoARopCAcQARobCg0IBxAGGAEiAzAwMTABEJvaCRoCGAN8FbYMIgQgASACKAEaJwgBEAEaGQoNCAEQBhgBIgMwMDEwAxAUGgIYA1m8dH0iBCABIAIoAxooCAEQCBoaCg0IARAIGAEiAzAwMTAEENEhGgIYA9QVeD8iBCABIAIoBBonCAkQARoZCg0ICRAGGAEiAzAwMTAGEAMaAhgDcqfsqSIEIAEgAigGGigIDxABGhoKDQgPEAYYASIDMDAxMAEQ_G8aAhgDzqcULyIEIAEgAigBGicIChAIGh"
		"kKDQgKEAgYASIDMDAxMAEQBxoCGAN3Vzc4IgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAfGgIYA056200iBCABIAIoARooCAgQARoaCg0ICBAGGAEiAzAwMTABENIMGgIYAyh7X1IiBCABIAIoARopCA0QARobCg0IDRAGGAEiAzAwMTABELudARoCGAM6mGVuIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARCX8wUaAhgDwKPr1iIEIAEgAigBGigIEBABGhoKDQgQEAYYASIDMDAxMAEQ_AsaAhgDtu2BdSIEIAEgAigBIgIIAQ==&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		"Url=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/MaterialIcons-Regular.83bebaf37c09c7e1c3ee.woff", "Referer=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/styles.5424f490b4fa36bba555.css", ENDITEM, 
		LAST);

	/* filling name sex DOB pin code address contact no */

	/* CLICK ON NEXT(INSURED PAGE) */

	/* FILLING NAME SEX DOB CITY NAME SCHOOL NAME */

	web_add_auto_header("Origin", 
		"https://lynxd.aig.co.jp");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("X-Client-Data", 
		"CIm2yQEIpbbJAQjEtskBCKmdygEIoqDLAQis8ssBCNzyywEI8PLLAQiz+MsBCJ75ywEI+/nLAQ==");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"92\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"92\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_custom_request("t", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&sr=1&tk=151644.308626&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"Body=q=02%20selected", 
		LAST);

	web_custom_request("t_2", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=2&sr=1&tk=676785.833151&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"Body=q=%3Ca%20i%3D0%3E%E9%AB%98%E6%A0%A1%E7%94%9F%E7%B7%8F%E5%90%88%E4%BF%9D%E9%9A%9C%E5%88%B6%E5%BA%A6%E3%80%80%E4%BF%9D%E9%9A%9C%E5%88%B6%E5%BA%A6%20%3C%2Fa%3E%3Ca%20i%3D1%3E%20%E3%82%AA%E3%83%B3%E3%83%A9%E3%82%A4%E3%83%B3%E5%8A%A0%E5%85%A5%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%83%95%E3%82%A9%E3%83%BC%E3%83%A0%3C%2Fa%3E&q=%E5%8A%A0%E5%85%A5%E4%BE%9D%E9%A0%BC%E8%80%85&q=%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85&q=%E6%89%B6%E9%A4%8A%E8%80%85&q=%E5%86%85%E5%AE%B9%E7%A2%BA%E8%AA%8D&q="
		"%E7%94%B3%E8%BE%BC%E5%AE%8C%E4%BA%86&q=%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85(%E5%AD%A6%E7%94%9F)%E3%83%BB%E6%89%B6%E9%A4%8A%E8%80%85%20%E6%83%85%E5%A0%B1%20&q=%E6%9C%AC%E4%BF%9D%E9%9A%9C%E5%88%B6%E5%BA%A6%E3%81%AE%E5%AF%BE%E8%B1%A1%E3%81%A8%E3%81%AA%E3%82%8B%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85%EF%BC%88%E5%AD%A6%E7%94%9F%E3%83%BB%E7%94%9F%E5%BE%92%EF%BC%89%E3%81%AE%E6%83%85%E5%A0%B1%E3%82%92%E5%85%A5%E5%8A%9B%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82&q="
		"%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85(%E5%AD%A6%E7%94%9F)&q=%E6%B0%8F%E5%90%8D%EF%BC%88%E6%BC%A2%E5%AD%97%EF%BC%89&q=%E5%A7%93&q=%E5%90%8D&q=%E6%B0%8F%E5%90%8D%EF%BC%88%EF%BE%8C%EF%BE%98%EF%BD%B6%EF%BE%9E%EF%BE%85%EF%BC%89&q=%EF%BD%BE%EF%BD%B2&q=%EF%BE%92%EF%BD%B2&q=%E2%80%BB%E8%87%AA%E5%8B%95%E3%81%A7%E5%8D%8A%E8%A7%92%EF%BD%B6%EF%BE%85%E3%81%B8%E5%A4%89%E6%8F%9B%E3%81%95%E3%82%8C%E3%81%BE%E3%81%99&q=%E6%80%A7%E5%88%A5%20&q=%E7%94%B7%E6%80%A7&q=%E5%A5%B3%E6%80%A7&q="
		"%E7%94%9F%E5%B9%B4%E6%9C%88%E6%97%A5%20&q=%E5%B9%B4&q=%E6%9C%88&q=%E6%97%A5&q=%E5%AD%A6%E6%A0%A1%E5%90%8D%20&q=%E5%B8%82%E5%8C%BA%E7%94%BA%E6%9D%91%E5%90%8D&q=%E5%AD%A6%E6%A0%A1%E5%90%8D&q=%E2%97%8F%E2%97%8F%E2%97%8F%E2%97%8F%E5%B9%B44%E6%9C%88%E3%81%8B%E3%82%89%E3%81%AE%E5%AD%A6%E9%BD%A2&q=%E6%89%B6%E9%A4%8A%E8%80%85%E6%83%85%E5%A0%B1%20&q=%3Ca%20i%3D0%3E%E2%80%BB%E6%89%B6%E9%A4%8A%E8%80%85%E3%81%A8%E3%81%AF%E3%80%81%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85(%E5%AD%A6%E7%94%9F)"
		"%E3%81%AE%E7%94%9F%E6%B4%BB%E8%B2%BB%E3%81%8A%E3%82%88%E3%81%B3%E5%AD%A6%E6%A5%AD%E8%B2%BB%E7%94%A8%E3%82%92%E8%B2%A0%E6%8B%85%E3%81%97%E3%81%A6%E7%94%9F%E8%A8%88%E3%82%92%E6%94%AF%E3%81%88%E3%81%A6%E3%81%84%E3%82%8B%E8%A6%AA%E6%A8%A9%E8%80%85%E3%82%92%E3%81%84%E3%81%84%E3%81%BE%E3%81%99%E3%80%82%20%3C%2Fa%3E%3Ca%20i%3D1%3E%E2%80%BB%E5%8A%A0%E5%85%A5%E4%BE%9D%E9%A0%BC%E8%80%85%EF%BC%88%E4%BF%9D%E8%AD%B7%E8%80%85%EF%BC%89%E3%81%A8%E6%89%B6%E9%A4%8A%E8%80%85%E3%81%8C%E5%90%8C%E4%B8%80%E3%81%AE%E5%A0"
		"%B4%E5%90%88%E3%81%AF%E4%B8%8B%E8%A8%98%E3%81%AB%E3%83%81%E3%82%A7%E3%83%83%E3%82%AF%E3%81%99%E3%82%8B%E3%81%93%E3%81%A8%E3%81%A7%E3%80%81%E6%83%85%E5%A0%B1%E3%81%8C%E8%87%AA%E5%8B%95%E5%85%A5%E5%8A%9B%E3%81%95%E3%82%8C%E3%81%BE%E3%81%99%E3%80%82%20%3C%2Fa%3E&q=%E5%8A%A0%E5%85%A5%E4%BE%9D%E9%A0%BC%E8%80%85(%E4%BF%9D%E8%AD%B7%E8%80%85)%E3%81%A8%E6%89%B6%E9%A4%8A%E8%80%85%E3%81%AF%E5%90%8C%E4%B8%80%E3%81%A7%E3%81%99&q=%20%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85(%E5%AD%A6%E7%94%9F)"
		"%E3%81%8B%E3%82%89%E3%81%BF%E3%81%9F%E7%B6%9A%E6%9F%84%20&q=%E7%88%B6%E8%A6%AA&q=%E6%AF%8D%E8%A6%AA&q=%E3%81%9D%E3%81%AE%E4%BB%96&q=%E2%80%BB%E3%81%9D%E3%81%AE%E4%BB%96%E3%81%AE%E5%A0%B4%E5%90%88%E3%81%AF%E5%8D%8A%E8%A7%92%EF%BD%B6%EF%BE%85%E3%81%A7%E3%81%94%E8%A8%98%E5%85%A5%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84&q=%E6%AC%A1%E3%80%80%E3%81%B8%E3%80%80&q=%E3%80%80%E6%88%BB%E3%80%80%E3%82%8B&q=(%E5%8F%96%E6%89%B1%E4%BB%A3%E7%90%86%E5%BA%97%E3%83%BB%E6%89%B1%E8%80%85%EF%BC%89&q="
		"%3Ca%20i%3D0%3E%20%E4%BB%A3%E7%90%86%E5%BA%97%E5%90%8D%EF%BC%9A%EF%BC%AB%EF%BD%81%EF%BD%8E%EF%BD%8A%EF%BD%89%EF%BC%91%EF%BC%92%EF%BC%93%E3%82%A2%E3%82%A4%E3%82%A6%E3%82%A8%E3%82%AA%E3%81%8A%E5%95%8F%E3%81%84%20%3C%2Fa%3E%3Ca%20i%3D1%3E%C2%A0%20%E3%80%92123-4556%E3%80%80%E3%81%8A%E5%95%8F%E3%81%84%E6%BC%A2%E5%AD%97%E6%BC%A2%E5%AD%97%20%3C%2Fa%3E%3Ca%20i%3D2%3E%C2%A0%20TEL%EF%BC%9A1234567890122343%20%3C%2Fa%3E%3Ca%20i%3D3%3E%C2%A0%20%E5%8F%97%E4%BB%98%E6%99%82%E9%96%93%EF%BC%9A%E3%81%8A%E5%95%8F%E3%"
		"81%84%E3%81%8A%E5%95%8F%E3%81%84%EF%BC%99%EF%BC%9A%EF%BC%90%EF%BC%90%EF%BD%9E%EF%BC%92%EF%BC%91%EF%BC%9A%EF%BC%90%EF%BC%90%20%3C%2Fa%3E%3Ca%20i%3D4%3E%C2%A0%20%E3%83%A1%E3%83%BC%E3%83%AB%E3%82%A2%E3%83%89%E3%83%AC%E3%82%B9%EF%BC%9AtestABCtestABCtestABCtestABCABCtestABCtest%40aig.com%20%3C%2Fa%3E%3Ca%20i%3D5%3E"
		"(%E5%BC%95%E5%8F%97%E4%BF%9D%E9%99%BA%E4%BC%9A%E7%A4%BE%E3%83%BB%E5%B9%B9%E4%BA%8B%E4%BF%9D%E9%99%BA%E4%BC%9A%E7%A4%BE%EF%BC%89%20%3C%2Fa%3E%3Ca%20i%3D6%3E%C2%A0%20AIG%E6%90%8D%E5%AE%B3%E4%BF%9D%E9%99%BA%E6%A0%AA%E5%BC%8F%E4%BC%9A%E7%A4%BE%20%3C%2Fa%3E%3Ca%20i%3D7%3E%C2%A0%20%E5%AD%A6%E6%A0%A1%E5%A5%91%E7%B4%84%E3%82%BB%E3%83%B3%E3%82%BF%E3%83%BC%20%3C%2Fa%3E%3Ca%20i%3D8%3E%C2%A0%20%E3%80%92930-0856%E3%80%80%E5%AF%8C%E5%B1%B1%E5%B8%82%E7%89%9B%E5%B3%B6%E6%96%B0%E7%94%BA5-5%20%E3%82%BF%E3%83%AF%E3%"
		"83%BC111%20%3C%2Fa%3E%3Ca%20i%3D9%3E%C2%A0%20TEL%3A076-443-8740%20%3C%2Fa%3E%3Ca%20i%3D10%3E%C2%A0%20%E5%8F%97%E4%BB%98%E6%99%82%E9%96%93%3A9%3A00-17%3A00%EF%BC%88%E5%9C%9F%E3%83%BB%E6%97%A5%E3%83%BB%E7%A5%9D%E6%97%A5%E3%83%BB%E5%B9%B4%E6%9C%AB%E5%B9%B4%E5%A7%8B%E3%82%92%E9%99%A4%E3%81%8F%EF%BC%89%20%3C%2Fa%3E&q=%C2%A9%20AIG%2C%20inc.&q=YYYY&q=1991%20selected&q=MM&q=01%20selected&q=DD", 
		EXTRARES, 
		"Url=https://translate.google.com/gen204?sl=ja&tl=en&textlen=11&ttt=1349&ttl=1860&ttf=2287&sr=1&nca=te_time&client=te_lib&logld=vTE_20210503_00", "Referer=https://lynxd.aig.co.jp/", ENDITEM, 
		LAST);

	web_custom_request("t_3", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=856262.783624&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"Body=q=%20%E5%90%8D%E5%8F%A4%E5%B1%8B%E5%B8%82%20&q=%20%E8%B1%8A%E6%A9%8B%E5%B8%82%20&q=%20%E5%B2%A1%E5%B4%8E%E5%B8%82%20&q=%20%E4%B8%80%E5%AE%AE%E5%B8%82%20&q=%20%E7%80%AC%E6%88%B8%E5%B8%82%20&q=%20%E5%8D%8A%E7%94%B0%E5%B8%82%20&q=%20%E6%98%A5%E6%97%A5%E4%BA%95%E5%B8%82%20&q=%20%E8%B1%8A%E5%B7%9D%E5%B8%82%20&q=%20%E6%B4%A5%E5%B3%B6%E5%B8%82%20&q=%20%E7%A2%A7%E5%8D%97%E5%B8%82%20&q=%20%E5%88%88%E8%B0%B7%E5%B8%82%20&q=%20%E8%B1%8A%E7%94%B0%E5%B8%82%20&q=%20%E5%AE%89%E5%9F%8E%E5%B8%82%20&q="
		"%20%E8%A5%BF%E5%B0%BE%E5%B8%82%20&q=%20%E8%92%B2%E9%83%A1%E5%B8%82%20&q=%20%E7%8A%AC%E5%B1%B1%E5%B8%82%20&q=%20%E5%B8%B8%E6%BB%91%E5%B8%82%20&q=%20%E6%B1%9F%E5%8D%97%E5%B8%82%20&q=%20%E5%B0%8F%E7%89%A7%E5%B8%82%20&q=%20%E7%A8%B2%E6%B2%A2%E5%B8%82%20&q=%20%E6%96%B0%E5%9F%8E%E5%B8%82%20&q=%20%E6%9D%B1%E6%B5%B7%E5%B8%82%20&q=%20%E5%A4%A7%E5%BA%9C%E5%B8%82%20&q=%20%E7%9F%A5%E5%A4%9A%E5%B8%82%20&q=%20%E7%9F%A5%E7%AB%8B%E5%B8%82%20&q=%20%E5%B0%BE%E5%BC%B5%E6%97%AD%E5%B8%82%20&q="
		"%20%E9%AB%98%E6%B5%9C%E5%B8%82%20&q=%20%E5%B2%A9%E5%80%89%E5%B8%82%20&q=%20%E8%B1%8A%E6%98%8E%E5%B8%82%20&q=%20%E6%84%9B%E7%9F%A5%E9%83%A1%20&q=%20%E6%97%A5%E9%80%B2%E5%B8%82%20&q=%20%E9%95%B7%E4%B9%85%E6%89%8B%E5%B8%82%20&q=%20%E6%B8%85%E9%A0%88%E5%B8%82%20&q=%20%E8%A5%BF%E6%98%A5%E6%97%A5%E4%BA%95%E9%83%A1%20&q=%20%E5%8C%97%E5%90%8D%E5%8F%A4%E5%B1%8B%E5%B8%82%20&q=%20%E4%B8%B9%E7%BE%BD%E9%83%A1%20&q=%20%E3%81%82%E3%81%BE%E5%B8%82%20&q=%20%E6%B5%B7%E9%83%A8%E9%83%A1%20&q="
		"%20%E5%BC%A5%E5%AF%8C%E5%B8%82%20&q=%20%E6%84%9B%E8%A5%BF%E5%B8%82%20&q=%20%E7%9F%A5%E5%A4%9A%E9%83%A1%20&q=%20%E9%A1%8D%E7%94%B0%E9%83%A1%E5%B9%B8%20&q=%20%E3%81%BF%E3%82%88%E3%81%97%E5%B8%82%20&q=%20%E5%8C%97%E8%A8%AD%E6%A5%BD%E9%83%A1%20&q=%20%E7%94%B0%E5%8E%9F%E5%B8%82%20", 
		LAST);

	web_custom_request("t_4", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=577372.928402&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"Body=q=%20%E8%B1%8A%E6%A9%8B%E5%B8%82%20&q=%E8%B1%8A%E6%A9%8B%E5%B8%82%20selected", 
		LAST);

	web_custom_request("t_5", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=176502.283832&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"Body=q=%20%E5%8D%83%E7%A8%AE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%E5%8D%83%E7%A8%AE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20selected", 
		LAST);

	web_custom_request("t_6", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=348012.240290&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"Body=q=%20%E5%8D%83%E7%A8%AE%E5%8F%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8D%83%E7%A8%AE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E4%BB%8A%E6%B1%A0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%8B%A5%E6%B0%B4%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%9F%8E%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%8C%AF%E7%94%AB%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E3%81%82%E3%81%9A%E3%81%BE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%A1%9C%E4%B8%98%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E7%9F%A2%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%86%A8%E5%A3%AB%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%85%AB%E7%8E%8B%E5%AD%90%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8C%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8C%97%E9%99%B5%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%A4%A7%E6%9B%BD%E6%A0%B9%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%BF%97%E8%B3%80%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%8B%A5%E8%91%89%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%A5%A0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E8%8F%8A%E4%BA%95%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%B1%B1%E7%94%B0%E6%9D%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%B1%B1%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B5%84%E5%BF%83%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%A4%A9%E7%A5%9E%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%B9%B3%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%90%8D%E5%A1%9A%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%97%A5%E6%AF%94%E6%B4%A5%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E5%BE%A1%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E9%BB%84%E9%87%91%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%AC%B9%E5%B3%B6%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%B1%8A%E6%AD%A3%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%B1%8A%E5%9B%BD%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%AC%88%E7%80%AC%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%89%8D%E6%B4%A5%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E4%BC%8A%E5%8B%A2%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E4%B8%B8%E3%81%AE%E5%86%85%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&"
		"q=%20%E7%99%BD%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%86%86%E4%B8%8A%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8C%97%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%A1%9C%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E9%A7%92%E6%96%B9%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%B7%9D%E5%90%8D%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%91%9E%E7%A9%82%E3%82%B1%E4%B8%98%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B4%A5%E8%B3%80%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E7%94%B0%E5%85%89%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%90%A9%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B1%90%E8%B7%AF%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%97%A5%E6%AF%94%E9%87%8E%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%97%A5%E6%AF%94%E9%87%8E%E4%B8%AD%E5%AD%A6%E6%A0%A1%E5%88%86%E6%A0%A1%20&q=%20%E5%AE%AE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B2%A2%E4%B8%8A%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E3%81%AF%E3%81%A8%E3%82%8A%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E4%B8%80%E8%89%B2%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E4%B8%80%E6%9F%B3%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%85%AB%E5%B9%A1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%98%AD%E5%92%8C%E6%A9%8B%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%B1%B1%E7%8E%8B%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8A%A9%E5%85%89%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E9%95%B7%E8%89%AF%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%AF%8C%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8D%97%E9%99%BD%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E6%9D%B1%E6%B8%AF%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B8%AF%E5%8D%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B8%AF%E5%8C%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%BD%93%E7%9F%A5%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%AE%9D%E7%A5%9E%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8D%97%E5%85%89%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%A4%A7%E6%B1%9F%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%98%8E%E8%B1%8A%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%A1%9C%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E6%96%B0%E9%83%8A%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%9C%AC%E5%9F%8E%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%90%8D%E5%8D%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%A4%A7%E6%A3%AE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%BF%97%E6%AE%B5%E5%91%B3%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%AE%88%E5%B1%B1%E8%A5%BF%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%AE%88%E5%B1%B1%E5%8C%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%AE%88%E5%B1%B1%E6%9D%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E5%AE%88%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%A3%AE%E5%AD%9D%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8D%83%E9%B3%A5%E4%B8%98%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%9D%B1%E9%99%B5%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%A4%A7%E9%AB%98%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%A5%9E%E6%B2%A2%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%89%87%E5%8F%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E9%B3%B4%E6%B5%B7%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E9%B3%B4%E5%AD%90%E5%8F%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&"
		"q=%20%E6%9C%89%E6%9D%BE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E9%AB%98%E9%87%9D%E5%8F%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%A5%9E%E4%B8%98%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%8C%AA%E9%AB%98%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%97%A4%E6%A3%AE%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8D%97%E5%A4%A9%E7%99%BD%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E4%B9%85%E6%96%B9%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%BE%A1%E5%B9%B8%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E5%A4%A9%E7%99%BD%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%B9%B3%E9%87%9D%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B4%A5%E5%85%B7%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8D%97%E9%83%A8%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8D%97%E7%A8%9C%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%8C%97%E9%83%A8%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%89%8D%E8%8A%9D%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%BE%BD%E7%94%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%90%89%E7%94%B0%E6%96%B9%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q="
		"%20%E9%AB%98%E5%B8%AB%E5%8F%B0%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%AB%A0%E5%8D%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E9%9D%92%E9%99%B5%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%9F%B3%E5%B7%BB%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E4%B8%AD%E9%83%A8%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%B1%8A%E5%B2%A1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E8%B1%8A%E5%9F%8E%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%89%9F%E5%91%82%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%85%AD%E3%83%84%E7%BE%8E%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&"
		"q=%20%E5%8D%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%9D%B1%E6%B5%B7%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E6%B2%B3%E5%90%88%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%B2%A9%E6%B4%A5%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%94%B2%E5%B1%B1%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%9F%A2%E4%BD%9C%E5%8C%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E7%9F%A2%E4%BD%9C%E4%B8%AD%E5%AD%A6%E6%A0%A1%20&q=%20%E5%9F%8E%E5%8C%97%E4%B8%AD%E5%AD%A6%E6%A0%A1%20", 
		LAST);

	web_custom_request("t_7", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=73461.523067&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"Body=q=%201%E6%89%8D%E5%85%90%E7%B5%84%20&q=%202%E6%89%8D%E5%85%90%E7%B5%84%20&q=%203%E6%89%8D%E5%85%90%E7%B5%84%20&q=%204%E6%89%8D%E5%85%90%E7%B5%84%20&q=%205%E6%89%8D%E5%85%90%E7%B5%84%20&q=%20%E6%96%B0%E5%B0%8F%E5%AD%A6%E6%A0%A1%EF%BC%91%E5%B9%B4%E7%94%9F%EF%BC%886%EF%BC%89%20", 
		LAST);

	/* selecting school age form dropdown */

	web_custom_request("t_8", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=946635.562181&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"Body=q=3%E6%89%8D%E5%85%90%E7%B5%84%20selected", 
		LAST);

	/* dependent info and relationship */

	/* click on next button(content cofirmation) */

	web_custom_request("t_9", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=750956.888994&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"Body=q=%E5%85%A5%E5%8A%9B%E6%83%85%E5%A0%B1%E3%81%AE%E3%81%94%E7%A2%BA%E8%AA%8D&q="
		"%E4%BD%8F%E6%89%80%E5%85%A5%E5%8A%9B%E3%81%AE%E4%B8%8D%E5%82%99%E3%81%AB%E3%82%88%E3%82%8A%E8%B3%87%E6%96%99%E3%81%8C%E3%81%8A%E5%B1%8A%E3%81%91%E3%81%A7%E3%81%8D%E3%81%AA%E3%81%8B%E3%81%A3%E3%81%9F%E3%82%8A%E3%80%81%E9%81%85%E5%BB%B6%E3%81%99%E3%82%8B%E3%82%B1%E3%83%BC%E3%82%B9%E3%81%8C%E5%A2%97%E3%81%88%E3%81%A6%E3%81%8A%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82%E5%86%8D%E5%BA%A6%E3%81%94%E7%A2%BA%E8%AA%8D%E3%82%92%E3%81%8A%E9%A1%98%E3%81%84%E3%81%97%E3%81%BE%E3%81%99%E3%80%82%20&q="
		"%E5%8A%A0%E5%85%A5%E4%BE%9D%E9%A0%BC%E8%80%85%EF%BC%88%E4%BF%9D%E8%AD%B7%E8%80%85%EF%BC%89%E6%83%85%E5%A0%B1&q=%20%EF%BC%A1%EF%BC%A2%EF%BC%A3%EF%BC%A4%E3%80%80%EF%BC%A1%EF%BC%A2%EF%BC%A3%EF%BC%A4%20&q=%20%EF%BE%8C%EF%BE%98%EF%BD%B6%EF%BE%9E%20%EF%BE%8C%EF%BE%98%EF%BD%B6%EF%BE%9E&q=%E6%80%A7%E5%88%A5&q=%E7%94%B7%E6%80%A7%C2%A0&q=%E7%94%9F%E5%B9%B4%E6%9C%88%E6%97%A5&q=1960%E5%B9%B401%E6%9C%8802%E6%97%A5%C2%A0&q=%E3%81%94%E8%87%AA%E5%AE%85%E4%BD%8F%E6%89%80&q=1050001&q="
		"%E5%8C%97%E6%B5%B7%E9%81%93%E3%80%80&q=%E3%83%95%E3%83%AA%E3%82%AC%E3%80%80&q=%EF%BC%92%E3%83%BC%EF%BC%92&q=%E3%81%8A%E9%9B%BB%E8%A9%B1%E7%95%AA%E5%8F%B7&q=0987654321%C2%A0&q=%E3%83%A1%E3%83%BC%E3%83%AB%E3%82%A2%E3%83%89%E3%83%AC%E3%82%B9%EF%BC%88%E5%A4%89%E6%9B%B4%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%9B%E3%82%93%EF%BC%89&q=S.Priyadharsani%40aig.co.jp%C2%A0&q=%E4%BF%AE%E3%80%80%E6%AD%A3%E3%80%80&q=%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85%EF%BC%88%E5%AD%A6%E7%94%9F%EF%BC%89%E6%83%85%E5%A0%B1&q="
		"%20%EF%BC%A5%EF%BC%A6%EF%BC%A7%EF%BC%A8%E3%80%80%EF%BC%A5%EF%BC%A6%EF%BC%A7%EF%BC%A8&q=1991%E5%B9%B401%E6%9C%8802%E6%97%A5%C2%A0&q=%E5%AD%A6%E6%A0%A1%E5%90%8D%EF%BC%88%E5%B8%82%E5%8C%BA%E7%94%BA%E6%9D%91%EF%BC%89&q=%E8%B1%8A%E6%A9%8B%E5%B8%82%C2%A0&q=%E5%8D%83%E7%A8%AE%E4%B8%AD%E5%AD%A6%E6%A0%A1%C2%A0&q=%E5%AD%A6%E9%BD%A2&q=3%E6%89%8D%E5%85%90%E7%B5%84%C2%A0&q=%E6%89%B6%E9%A4%8A%E8%80%85%E6%83%85%E5%A0%B1&q=%20%EF%BC%A1%EF%BC%A2%EF%BC%A3%EF%BC%A4%E3%80%80%EF%BC%A1%EF%BC%A2%EF%BC%A3%EF%BC%A4&q="
		"%E7%B6%9A%E6%9F%84&q=%E7%88%B6%E8%A6%AA%C2%A0&q=%E5%8A%A0%E5%85%A5%E6%83%85%E5%A0%B1&q=%E5%8A%A0%E5%85%A5%E4%BE%9D%E9%A0%BC%E6%97%A5&q=2021%E5%B9%B407%E6%9C%8827%E6%97%A5%C2%A0&q=%E8%A3%9C%E5%84%9F%E9%96%8B%E5%A7%8B%E6%97%A5&q=2021%E5%B9%B407%E6%9C%8828%E6%97%A5%E5%8D%88%E5%89%8D0%E6%99%82%C2%A0&q=%E5%8A%A0%E5%85%A5%E3%83%97%E3%83%A9%E3%83%B3&q=GB%2025%2C770%E5%86%86&q=%E5%8F%A3%E5%BA%A7%E6%8C%AF%E6%9B%BF%E6%89%95%E3%81%84%20&q="
		"%E5%BD%93%E3%82%B5%E3%82%A4%E3%83%88%E3%81%AE%E5%8F%A3%E5%BA%A7%E6%8C%AF%E6%9B%BF%E7%99%BB%E9%8C%B2%E3%81%AF%E4%B8%89%E8%8F%B1UFJ%E3%83%95%E3%82%A1%E3%82%AF%E3%82%BF%E3%83%BC%E6%A0%AA%E5%BC%8F%E4%BC%9A%E7%A4%BE%E3%81%AE%E5%8F%A3%E5%BA%A7%E6%8C%AF%E6%9B%BF%E5%8F%97%E4%BB%98%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%E3%81%A7%E5%8F%97%E4%BB%98%E3%81%84%E3%81%9F%E3%81%97%E3%81%BE%E3%81%99%E3%80%82%20&q="
		"%E6%AD%BB%E4%BA%A1%E4%BF%9D%E9%99%BA%E9%87%91%E5%8F%97%E5%8F%96%E4%BA%BA%E3%81%AF%E3%80%81%E6%B3%95%E5%AE%9A%E7%9B%B8%E7%B6%9A%E4%BA%BA%E3%81%A8%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82&q="
		"%E5%AD%A6%E6%A5%AD%E8%B2%BB%E7%94%A8%E3%81%8C%E3%82%BB%E3%83%83%E3%83%88%E3%81%95%E3%82%8C%E3%81%A6%E3%81%84%E3%82%8B%E5%A0%B4%E5%90%88%E3%80%81%E5%AD%A6%E6%A5%AD%E8%B2%BB%E7%94%A8%E3%81%AE%E6%94%AF%E6%89%95%E5%AF%BE%E8%B1%A1%E6%9C%9F%E9%96%93%E7%B5%82%E4%BA%86%E6%97%A5%E3%82%92%E3%83%91%E3%83%B3%E3%83%95%E3%83%AC%E3%83%83%E3%83%88%E3%81%AB%E3%81%A6%E3%81%94%E7%A2%BA%E8%AA%8D%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84&q="
		"%E9%87%8D%E8%A6%81%E4%BA%8B%E9%A0%85%E8%AA%AC%E6%98%8E%E3%81%AB%E9%96%A2%E3%81%99%E3%82%8B%E5%90%8C%E6%84%8F&q="
		"%E3%81%94%E5%8A%A0%E5%85%A5%E5%89%8D%E3%81%AB%E5%BF%85%E3%81%9A%E3%81%94%E7%90%86%E8%A7%A3%E3%81%84%E3%81%9F%E3%81%A0%E3%81%8D%E3%81%9F%E3%81%84%E5%A4%A7%E5%88%87%E3%81%AA%E6%83%85%E5%A0%B1%E3%81%8C%E6%8E%B2%E8%BC%89%E3%81%95%E3%82%8C%E3%81%A6%E3%81%84%E3%81%BE%E3%81%99%E3%80%82%E5%BF%85%E3%81%9A%E6%9C%80%E5%BE%8C%E3%81%BE%E3%81%A7%E3%81%8A%E8%AA%AD%E3%81%BF%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82&q=%E9%87%8D%E8%A6%81%E4%BA%8B%E9%A0%85%E8%AA%AC%E6%98%8E%E6%9B%B8%EF%BC%88PDF)"
		"%E3%83%80%E3%82%A6%E3%83%B3%E3%83%AD%E3%83%BC%E3%83%89%EF%BC%88PDF%20%E2%97%8B%E2%97%8BkB%EF%BC%89&q=%E2%80%BB%E9%87%8D%E8%A6%81%E4%BA%8B%E9%A0%85%E8%AA%AC%E6%98%8E%E6%9B%B8%E3%81%AF%E5%8D%B0%E5%88%B7%E3%82%82%E3%81%97%E3%81%8F%E3%81%AF%E3%81%94%E8%87%AA%E8%BA%AB%E3%81%AE%E7%AB%AF%E6%9C%AB%E3%81%AB%E4%BF%9D%E5%AD%98%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82&q="
		"%E5%8D%81%E5%88%86%E3%81%94%E7%90%86%E8%A7%A3%E3%81%AE%E4%B8%8A%E3%80%81%E5%90%8C%E6%84%8F%E3%81%84%E3%81%9F%E3%81%A0%E3%81%91%E3%82%8B%E6%96%B9%E3%81%AF%E3%80%81%E4%B8%8B%E8%A8%98%E3%81%AB%E3%83%81%E3%82%A7%E3%83%83%E3%82%AF%E3%81%97%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82&q=%E9%87%8D%E8%A6%81%E4%BA%8B%E9%A0%85%E8%AA%AC%E6%98%8E%E6%9B%B8%E3%81%AE%E5%86%85%E5%AE%B9%E3%81%AB%E5%90%8C%E6%84%8F%E3%81%97%E3%81%BE%E3%81%99%E3%80%82&q="
		"%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%83%9C%E3%82%BF%E3%83%B3%E3%82%92%E6%8A%BC%E3%81%99%E3%81%A8%E5%A4%96%E9%83%A8%E3%81%AE%E6%B1%BA%E6%B8%88%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%E3%81%B8%E7%A7%BB%E5%8B%95%E3%81%97%E3%81%BE%E3%81%99%E3%80%82&q=%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF", 
		LAST);

	/* checking givin details and check agree box */

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Client-Data");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_url("favicon.ico", 
		"URL=https://lynxd.aig.co.jp/favicon.ico", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	/* click on appliction button */

	web_add_auto_header("Origin", 
		"https://lynxd.aig.co.jp");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	lr_think_time(8);

	web_custom_request("saveSubscription", 
		"URL=https://lynxd.aig.co.jp/Schoolservice/dist/school/uiuxServices/saveSubscription", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/Schooluiux/SchoolDigital/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"BodyBinary={\"root\":{\"registrationId\":\"0000000000001495\",\"fiscalYear\":\"2021\",\"orgCode\":\"97001294\",\"subOrgCode\":\"97001294\",\"branchCd\":\"FB\",\"producerCd\":\"19X8\",\"groupDetails\":{\"orgName\":\"\\xE4\\xB8\\x80\\xE5\\xB2\\x90\\xE9\\x98\\x9C\\xE7\\x9C\\x8C\\xE9\\xAB\\x98\\xE7\\xAD\\x89\\xE5\\xAD\\xA6\\xE6\\xA0\\xA1\\xEF\\xBC\\xB0\\xEF\\xBC\\xB4\\xEF\\xBC\\xA1\\xE9\\x80\\xA3\\xE5\\x90\\x88\\xE4\\xBC\\x9A\",\"orgCode\":\"97001294\",\"subOrgName\":\""
		"\\xE5\\xB2\\x90\\xE9\\x98\\x9C\\xE7\\x9C\\x8C\\xE9\\xAB\\x98\\xE7\\xAD\\x89\\xE5\\xAD\\xA6\\xE6\\xA0\\xA1\\xEF\\xBC\\xB0\\xEF\\xBC\\xB4\\xEF\\xBC\\xA1\\xE9\\x80\\xA3\\xE5\\x90\\x88\\xE4\\xBC\\x9A\\xEF\\xBC\\x92\\xEF\\xBC\\x92\",\"subOrgCode\":\"97001294\",\"businessType\":\"N\",\"systemName\":\"\\xE9\\xAB\\x98\\xE6\\xA0\\xA1\\xE7\\x94\\x9F\\xE7\\xB7\\x8F\\xE5\\x90\\x88\\xE4\\xBF\\x9D\\xE9\\x9A\\x9C\\xE5\\x88\\xB6\\xE5\\xBA\\xA6\",\"schoolAge\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\"]},\"agencyInfo\":"
		"{\"agencyPhoneNo\":\"1234567890122343\",\"agencyName\":\"\\xEF\\xBC\\xAB\\xEF\\xBD\\x81\\xEF\\xBD\\x8E\\xEF\\xBD\\x8A\\xEF\\xBD\\x89\\xEF\\xBC\\x91\\xEF\\xBC\\x92\\xEF\\xBC\\x93\\xE3\\x82\\xA2\\xE3\\x82\\xA4\\xE3\\x82\\xA6\\xE3\\x82\\xA8\\xE3\\x82\\xAA\\xE3\\x81\\x8A\\xE5\\x95\\x8F\\xE3\\x81\\x84\",\"agencyZipCode\":\"123-4556\",\"agencyAddress\":\"\\xE3\\x81\\x8A\\xE5\\x95\\x8F\\xE3\\x81\\x84\\xE6\\xBC\\xA2\\xE5\\xAD\\x97\\xE6\\xBC\\xA2\\xE5\\xAD\\x97\",\"agencyEmail\":\""
		"testABCtestABCtestABCtestABCABCtestABCtest@aig.com\",\"inquiryDateTime\":\"\\xE3\\x81\\x8A\\xE5\\x95\\x8F\\xE3\\x81\\x84\\xE3\\x81\\x8A\\xE5\\x95\\x8F\\xE3\\x81\\x84\\xEF\\xBC\\x99\\xEF\\xBC\\x9A\\xEF\\xBC\\x90\\xEF\\xBC\\x90\\xEF\\xBD\\x9E\\xEF\\xBC\\x92\\xEF\\xBC\\x91\\xEF\\xBC\\x9A\\xEF\\xBC\\x90\\xEF\\xBC\\x90\"},\"paymentDetails\":{\"paymentStatus\":\"1\"},\"planRegistration\":{\"selectedPlanName\":\"GB\",\"selectedPlanPremium\":\"25770\",\"emailAddress\":\"S.Priyadharsani@aig.co.jp\",\""
		"isConcentAgreed\":true},\"otherDetails\":{\"compensationStartDate\":\"20210728\",\"compensationEndDate\":\"20230331\",\"applicationDate\":\"20200409\",\"systemDate\":\"20210727\",\"isPolStartPast\":true},\"partyDetails\":{\"subscriberLastNameKanji\":\"\\xEF\\xBC\\xA1\\xEF\\xBC\\xA2\\xEF\\xBC\\xA3\\xEF\\xBC\\xA4\",\"subscriberFirstNameKanji\":\"\\xEF\\xBC\\xA1\\xEF\\xBC\\xA2\\xEF\\xBC\\xA3\\xEF\\xBC\\xA4\",\"subscriberLastNameKana\":\"\\xEF\\xBE\\x8C\\xEF\\xBE\\x98\\xEF\\xBD\\xB6\\xEF\\xBE\\x9E\","
		"\"subscriberFirstNameKana\":\"\\xEF\\xBE\\x8C\\xEF\\xBE\\x98\\xEF\\xBD\\xB6\\xEF\\xBE\\x9E\",\"subscriberGender\":\"\\xE7\\x94\\xB7\\xE6\\x80\\xA7\",\"subscriberDob\":\"19600102\",\"subscriberZipCode\":\"1050001\",\"subscriberPrefecture\":\"\\xE5\\x8C\\x97\\xE6\\xB5\\xB7\\xE9\\x81\\x93\",\"subscriberCityKanji\":\"\\xE3\\x83\\x95\\xE3\\x83\\xAA\\xE3\\x82\\xAC\",\"subscriberStreetAddressKanji\":\"\\xEF\\xBC\\x92\\xE3\\x83\\xBC\\xEF\\xBC\\x92\",\"subscriberBuildingNameKanji\":\"\",\""
		"subscriberPhoneNumber1\":\"0987654321\",\"subscriberPhoneNumber2\":\"0987654321\",\"isGuardianSubscriberSame\":true,\"guardianLastNameKanji\":\"\\xEF\\xBC\\xA1\\xEF\\xBC\\xA2\\xEF\\xBC\\xA3\\xEF\\xBC\\xA4\",\"guardianFirstNameKanji\":\"\\xEF\\xBC\\xA1\\xEF\\xBC\\xA2\\xEF\\xBC\\xA3\\xEF\\xBC\\xA4\",\"guardianLastNameKana\":\"\\xEF\\xBE\\x8C\\xEF\\xBE\\x98\\xEF\\xBD\\xB6\\xEF\\xBE\\x9E\",\"guardianFirstNameKana\":\"\\xEF\\xBE\\x8C\\xEF\\xBE\\x98\\xEF\\xBD\\xB6\\xEF\\xBE\\x9E\",\"relationship\":\""
		"\\xE7\\x88\\xB6\\xE8\\xA6\\xAA\",\"relationshipOther\":\"\"},\"insuredDetails\":{\"insuredLastNameKanji\":\"\\xEF\\xBC\\xA5\\xEF\\xBC\\xA6\\xEF\\xBC\\xA7\\xEF\\xBC\\xA8\",\"insuredFirstNameKanji\":\"\\xEF\\xBC\\xA5\\xEF\\xBC\\xA6\\xEF\\xBC\\xA7\\xEF\\xBC\\xA8\",\"insuredLastNameKana\":\"\\xEF\\xBE\\x8C\\xEF\\xBE\\x98\\xEF\\xBD\\xB6\\xEF\\xBE\\x9E\",\"insuredFirstNameKana\":\"\\xEF\\xBE\\x8C\\xEF\\xBE\\x98\\xEF\\xBD\\xB6\\xEF\\xBE\\x9E\",\"insuredDob\":\"19910102\",\"insuredGender\":\""
		"\\xE7\\x94\\xB7\\xE6\\x80\\xA7\",\"insuredAddressKanji\":\" \",\"insuredAddressKana\":\" \",\"insuredZipCode\":\" \"},\"email\":{\"thankYouEmail\":{\"emailAddress\":\"S.Priyadharsani@aig.co.jp\",\"confirmationEmailAddress\":\"\",\"emailSubject\":\"Pre Registration Successful\",\"emailTemplate\":\"\",\"businessType\":\"N\"},\"paymentConfirmationEmail\":{\"emailAddress\":\"\",\"confirmationEmailAddress\":\"\",\"emailSubject\":\"\",\"emailTemplate\":\"\"},\"preRegistrationEmail\":{\"emailAddress\":\""
		"S.Priyadharsani@aig.co.jp\",\"confirmationEmailAddress\":\"S.Priyadharsani@aig.co.jp\",\"emailSubject\":\"Pre Registration Successful\",\"emailTemplate\":\"Click the below link\"}},\"schoolDetails\":{\"schoolName\":\"\\xE5\\x8D\\x83\\xE7\\xA8\\xAE\\xE4\\xB8\\xAD\\xE5\\xAD\\xA6\\xE6\\xA0\\xA1\",\"schoolCity\":\"\\xE8\\xB1\\x8A\\xE6\\xA9\\x8B\\xE5\\xB8\\x82\",\"schoolAge\":\"3\",\"schoolType\":\"\"},\"mailTriggerIndex\":\"2\"}}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_header("X-Client-Data", 
		"CIm2yQEIpbbJAQjEtskBCKmdygEIoqDLAQis8ssBCNzyywEI8PLLAQiz+MsBCJ75ywEI+/nLAQ==");

	web_custom_request("t_10", 
		"URL=https://translate.googleapis.com/translate_a/t?anno=3&client=te_lib&format=html&v=1.0&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&logld=vTE_20210503_00&sl=ja&tl=en&tc=1&dom=1&sr=1&tk=654058.991012&mode=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lynxd.aig.co.jp/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"Body=q=%E7%B7%8F%E5%90%88%E4%BF%9D%E9%9A%9C%E5%88%B6%E5%BA%A6%E3%81%AE%E5%8A%A0%E5%85%A5%E5%8F%97%E4%BB%98%E3%81%8C%E5%AE%8C%E4%BA%86%E3%81%84%E3%81%9F%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82&q="
		"%E3%81%8A%E6%89%8B%E7%B6%9A%E3%81%8D%E5%AE%8C%E4%BA%86%E3%81%97%E3%81%9F%E6%97%A8%E3%82%92%E3%83%A1%E3%83%BC%E3%83%AB%E3%81%AB%E3%81%A6%E3%81%8A%E9%80%81%E3%82%8A%E3%81%84%E3%81%9F%E3%81%97%E3%81%BE%E3%81%99%E3%81%AE%E3%81%A7%E3%80%81%E3%81%94%E7%A2%BA%E8%AA%8D%E3%81%84%E3%81%9F%E3%81%A0%E3%81%8D%E3%80%81%E5%8A%A0%E5%85%A5%E8%80%85%E8%A8%BC%E3%81%8C%E5%88%B0%E7%9D%80%E3%81%99%E3%82%8B%E3%81%BE%E3%81%A7%E3%81%AF%E4%BF%9D%E7%AE%A1%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%E3%80%82&q="
		"%E3%81%AA%E3%81%8A%E3%80%81%E5%8A%A0%E5%85%A5%E8%80%85%E8%A8%BC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6%E3%81%AF%E8%A3%9C%E5%84%9F%E9%96%8B%E5%A7%8B%E6%97%A5%E3%81%AE1%E3%83%B6%E6%9C%88%E5%8D%8A~2%E3%83%B6%E6%9C%88%E5%BE%8C%E3%81%AB%E9%83%B5%E9%80%81%E3%81%84%E3%81%9F%E3%81%97%E3%81%BE%E3%81%99%E3%81%AE%E3%81%A7%E3%80%81%E3%81%82%E3%82%89%E3%81%8B%E3%81%98%E3%82%81%E3%81%94%E4%BA%86%E6%89%BF%E9%A1%98%E3%81%84%E3%81%BE%E3%81%99%E3%80%82&q="
		"%EF%BC%88%E3%83%A1%E3%83%BC%E3%83%AB%E3%82%92%E3%81%94%E7%A2%BA%E8%AA%8D%E5%BE%8C%E3%80%81%E3%81%93%E3%81%AE%E7%94%BB%E9%9D%A2%E3%82%92%E9%96%89%E3%81%98%E3%81%A6%E3%81%8F%E3%81%A0%E3%81%95%E3%81%84%EF%BC%89&q=%E3%81%8A%E7%94%B3%E8%BE%BC%E5%86%85%E5%AE%B9&q=%E5%8A%A0%E5%85%A5%E8%80%85%E7%95%AA%E5%8F%B7&q=3000006372&q=%E5%8A%A0%E5%85%A5%E4%BE%9D%E9%A0%BC%E8%80%85%EF%BC%88%E4%BF%9D%E8%AD%B7%E8%80%85%EF%BC%89%E6%B0%8F%E5%90%8D&q="
		"%E8%A2%AB%E4%BF%9D%E9%99%BA%E8%80%85%EF%BC%88%E5%AD%A6%E7%94%9F%EF%BC%89%E6%B0%8F%E5%90%8D&q=%20%EF%BC%A5%EF%BC%A6%EF%BC%A7%EF%BC%A8%E3%80%80%EF%BC%A5%EF%BC%A6%EF%BC%A7%EF%BC%A8%20&q=%E5%9B%A3%E4%BD%93%E5%90%8D&q=%20%E9%AB%98%E6%A0%A1%E7%94%9F%E7%B7%8F%E5%90%88%E4%BF%9D%E9%9A%9C%E5%88%B6%E5%BA%A6%20&q=%202021%E5%B9%B407%E6%9C%8827%E6%97%A5%20&q=%202021%E5%B9%B407%E6%9C%8828%E6%97%A5%E5%8D%88%E5%89%8D0%E6%99%82%20&q=%20GB%20&q=%E4%BF%9D%E9%99%BA%E6%96%99&q=%2025%2C770%E5%86%86%20&q="
		"%E5%8F%96%E6%89%B1%E4%BB%A3%E7%90%86%E5%BA%97%E3%83%BB%E6%89%B1%E8%80%85%E6%83%85%E5%A0%B1&q="
		"%3Ca%20i%3D0%3E%20%EF%BC%AB%EF%BD%81%EF%BD%8E%EF%BD%8A%EF%BD%89%EF%BC%91%EF%BC%92%EF%BC%93%E3%82%A2%E3%82%A4%E3%82%A6%E3%82%A8%E3%82%AA%E3%81%8A%E5%95%8F%E3%81%84%3C%2Fa%3E%3Ca%20i%3D1%3E%20%E3%80%92123-4556%3C%2Fa%3E%3Ca%20i%3D2%3E%20%E3%81%8A%E5%95%8F%E3%81%84%E6%BC%A2%E5%AD%97%E6%BC%A2%E5%AD%97%3C%2Fa%3E%3Ca%20i%3D3%3E%20TEL%20%3A%201234567890122343%3C%2Fa%3E%3Ca%20i%3D4%3E%20%E5%8F%97%E4%BB%98%E6%99%82%E9%96%93%3A%20%E3%81%8A%E5%95%8F%E3%81%84%E3%81%8A%E5%95%8F%E3%81%84%EF%BC%99%EF%BC%9A%EF%BC"
		"%90%EF%BC%90%EF%BD%9E%EF%BC%92%EF%BC%91%EF%BC%9A%EF%BC%90%EF%BC%90%3C%2Fa%3E%3Ca%20i%3D5%3E%20%E3%83%A1%E3%83%BC%E3%83%AB%E3%82%A2%E3%83%89%E3%83%AC%E3%82%B9%3A%3C%2Fa%3E%3Ca%20i%3D6%3E%20testABCtestABCtestABCtestABCABCtestABCtest%40aig.com%20%3C%2Fa%3E&q=%E5%96%B6%E6%A5%AD%E5%BA%97%E6%83%85%E5%A0%B1&q="
		"%3Ca%20i%3D0%3E%20AIG%E6%90%8D%E5%AE%B3%E4%BF%9D%E9%99%BA%E6%A0%AA%E5%BC%8F%E4%BC%9A%E7%A4%BE%3C%2Fa%3E%3Ca%20i%3D1%3E%20%E5%AD%A6%E6%A0%A1%E5%A5%91%E7%B4%84%E3%82%BB%E3%83%B3%E3%82%BF%E3%83%BC%3C%2Fa%3E%3Ca%20i%3D2%3E%20%E3%80%92930-0856%3C%2Fa%3E%3Ca%20i%3D3%3E%20%E5%AF%8C%E5%B1%B1%E5%B8%82%E7%89%9B%E5%B3%B6%E6%96%B0%E7%94%BA5-5%20%E3%82%BF%E3%83%AF%E3%83%BC111%3C%2Fa%3E%3Ca%20i%3D4%3E%20TEL%3A076-443-8740%3C%2Fa%3E%3Ca%20i%3D5%3E%20%E5%8F%97%E4%BB%98%E6%99%82%E9%96%93%EF%BC%9A%3C%2Fa%3E%3Ca%20i"
		"%3D6%3E%209%3A00-17%3A00%EF%BC%88%E5%9C%9F%E3%83%BB%E6%97%A5%E3%83%BB%E7%A5%9D%E6%97%A5%E3%83%BB%E5%B9%B4%E6%9C%AB%E5%B9%B4%E5%A7%8B%E3%82%92%E9%99%A4%E3%81%8F%EF%BC%89%20%3C%2Fa%3E&q=%E7%94%B3%E3%81%97%E8%BE%BC%E3%81%BF%E3%81%8C%E5%AE%8C%E4%BA%86%E3%81%97%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82&q=Close", 
		LAST);

	/* click on close button(application completed popup) */

	/* landed on application completed page */

	/* close */

	return 0;
}