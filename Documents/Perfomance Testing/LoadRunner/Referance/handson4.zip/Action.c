Action()
{
	
	char sent1[]="I am perfomance Testing";
	char sent2[]="Performance cost $ many many $";
	int no,i=0,j=0,a=0,b=0,c1=0,c2=0,c3=0,k=0,m;
	char sent[50],sentt[20][20],r[100],*pos,out[100]="";
	
	no=(rand()%strlen(sent2))+1;
	
	fprintf(file,"Iteration --%d for count=%d\n",itr,no);
	if(no<0)
	{
		fprinf(file,"Merging not possible");
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_PASS);
	}
	
	if(no>strlen(sent2))
	   {
	   	 fprinf(file,"%d exceeds length of sentance2",no);
	   }
	   strcpy(sent,sent1);
	   strcat(sent," ");
	   strncat(sent,sent2,no);
	   fprintf(file,"Merged string:%s\n",sent);
	   lr_output_message("%s",sent);
	   
	   for(i=0;i<=strlen(sent);i++)
	   {
	   	if(sent[i]==' '||sent[i]=='\0')
	   	{
	   		sentt[a][b]='\0';
	   		a++;
	   		b=0;
	   	}
	   	else
	   	{
	   		sentt[a][b]=sent[i];
	   		b++;
	   	}
	   }
	   for(i=0;i<a;i++)
	   {
	   	if((strcmp(sentt[i],"performance"))==0)
	   	{
	   		c1++;
	   	}
	   	if((strcmp(sentt[i],"Performance"))==0)
	   	{
	   		c2++;
	   	}
	   	if((strcmp(sentt[i],"performance"))==0)
	   	{
	   		c3++;
	   	}
	   }
	
	lr_output_message("Count of performance:%d",c1);
	lr_output_message("Count of performance:%d",c2);
	lr_output_message("Count of case insensitive performance:%d",c3);
	
	
	
	 for(i=0;i<a;i++)
	   {
		   	if((strcmp(sentt[i],"performance"))==0)
		   	{
		   		strcpy(sentt[i],"Automation");
		   	}
	   }
	 for(i=0;i<a;i++)
	 {
	 	for(j=0;sentt[i][j]!='\0';j++)
	 	{
	 		r[k++]=sentt[i][j];
	 	}
	 	r[k++]=' ';
	 }
	 r[k]='\0';
	 for(i=0;i<a;i++)
	 {
	 	strcat(out,sentt[i]);
	 }
	 lr_output_message("%s",r);
	 
	 
	 pos=(char *)strstr(r,"Automation");
	 if(pos!=NULL)
	 {
	 	m=(int)(pos-r+1);
	 	lr_output_message("Automantion is at position %d",m);
	 	fprintf(file,"Found the word automation at position %d\n",m);
	 }
	 else
	 {
	 	lr_output_message("Automantion not found");
	 	fprintf(file,"Automantion not found\n");
	 }
	 lr_output_message("Text without spaces:%s\n",out);
	 fprintf(file,"Text without spaces:%s\n",out);
	 fprintf(file,"%s\n **********************************");
	 itr++;      
	return 0;
}
