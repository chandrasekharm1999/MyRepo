vuser_init()
{
	filename ="string_file.txt";
	if((file = fopen(filename,"w"))==NULL)
	{
		lr_error_message("cannot open %s",filename);
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_AUTO);
		return -1;
	}
	return 0;
}
